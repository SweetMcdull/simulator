# -*- coding: utf-8 -*-

from modellibrary.src.main.python.core.common.variable import Variable
from modellibrary.src.main.python.core.models.asm2d.params.constants import VariableTypeName
from ..constants import InitComponentDefaultValue


class InitParams:
    """初始类参数"""

    def __init__(self):
        self.so = Variable(VariableTypeName.SO, default=InitComponentDefaultValue.SO)
        self.sf = Variable(VariableTypeName.SF, default=InitComponentDefaultValue.SF)
        self.sa = Variable(VariableTypeName.SA, default=InitComponentDefaultValue.SA)
        self.snh = Variable(VariableTypeName.SNH, default=InitComponentDefaultValue.SNH)
        self.sno = Variable(VariableTypeName.SNO, default=InitComponentDefaultValue.SNO)
        self.spo = Variable(VariableTypeName.SPO, default=InitComponentDefaultValue.SPO)
        self.si = Variable(VariableTypeName.SI, default=InitComponentDefaultValue.SI)
        self.salk = Variable(VariableTypeName.SALK, default=InitComponentDefaultValue.SALK)
        self.snn = Variable(VariableTypeName.SNN, default=InitComponentDefaultValue.SNN)

        self.tss_list = [Variable(VariableTypeName.TSS, default=getattr(InitComponentDefaultValue, f"TSS_{index}"))
                         for index in range(1, 21)]

    def update_by_t(self, t: float):
        self.so.update_value_by_t(t)
        self.sf.update_value_by_t(t)
        self.sa.update_value_by_t(t)
        self.snh.update_value_by_t(t)
        self.sno.update_value_by_t(t)
        self.spo.update_value_by_t(t)
        self.si.update_value_by_t(t)
        self.salk.update_value_by_t(t)
        self.snn.update_value_by_t(t)

        for tss in self.tss_list:
            tss.update_value_by_t(t)
