# -*- coding: utf-8 -*-


class InflowDefaultValue:
    """进水水量,水质默认值"""
    FLOW = 1000.
    SO = 0.
    SF = 0.
    SA = 0.
    SNH = 25.
    SNO = 0.
    SPO = 10.
    SI = 30.
    SALK = 7.
    SNN = 0.
    XI = 100.
    XS = 130.
    XH = 0.
    XPAO = 0.
    XPP = 0.
    XPHA = 0.
    XAUT = 0.
    XMEOH = 0.
    XMEP = 0.
    XII = 30.
