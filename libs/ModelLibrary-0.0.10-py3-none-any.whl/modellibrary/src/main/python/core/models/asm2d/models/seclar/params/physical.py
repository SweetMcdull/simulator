# -*- coding: utf-8 -*-
from modellibrary.src.main.python.core.common.variable import Variable
from ..constants import PhysicalTypeName, PhysicalDefaultValue


class PhysicalParams:
    """物理参数"""

    def __init__(self):
        self.area = Variable(PhysicalTypeName.AREA, default=PhysicalDefaultValue.AREA)
        self.depth = Variable(PhysicalTypeName.DEPTH, default=PhysicalDefaultValue.DEPTH)
        self.total_layer = Variable(PhysicalTypeName.TOTAL_LAYER, default=PhysicalDefaultValue.TOTAL_LAYER)
        self.feed_layer = Variable(PhysicalTypeName.FEED_LAYER, default=PhysicalDefaultValue.FEED_LAYER)

    def update_by_t(self, t: float):
        self.area.update_value_by_t(t)
        self.depth.update_value_by_t(t)
        self.total_layer.update_value_by_t(t)
        self.feed_layer.update_value_by_t(t)
