# -*- coding: utf-8 -*-
from .constants import StoichiTypeName, StoichiDefaultValue
from modellibrary.src.main.python.core.common.variable import Variable


class StoichiParams:
    # 化学计量学系数
    def __init__(self):
        self.icv = Variable(name=StoichiTypeName.ICV, default=StoichiDefaultValue.ICV)
        self.ivt = Variable(name=StoichiTypeName.IVT, default=StoichiDefaultValue.IVT)
        self.fbod = Variable(name=StoichiTypeName.FBOD, default=StoichiDefaultValue.FBOD)

        self.insi = Variable(name=StoichiTypeName.INSI, default=StoichiDefaultValue.INSI)
        self.insf = Variable(name=StoichiTypeName.INSF, default=StoichiDefaultValue.INSF)
        self.inxi = Variable(name=StoichiTypeName.INXI, default=StoichiDefaultValue.INXI)
        self.inxs = Variable(name=StoichiTypeName.INXS, default=StoichiDefaultValue.INXS)
        self.inbm = Variable(name=StoichiTypeName.INBM, default=StoichiDefaultValue.INBM)
        self.ipsi = Variable(name=StoichiTypeName.IPSI, default=StoichiDefaultValue.IPSI)
        self.ipsf = Variable(name=StoichiTypeName.IPSF, default=StoichiDefaultValue.IPSF)
        self.ipxi = Variable(name=StoichiTypeName.IPXI, default=StoichiDefaultValue.IPXI)
        self.ipxs = Variable(name=StoichiTypeName.IPXS, default=StoichiDefaultValue.IPXS)
        self.ipbm = Variable(name=StoichiTypeName.IPBM, default=StoichiDefaultValue.IPBM)

        self.itssxi = Variable(name=StoichiTypeName.ITSSXI, default=StoichiDefaultValue.ITSSXI)
        self.itssxs = Variable(name=StoichiTypeName.ITSSXS, default=StoichiDefaultValue.ITSSXS)
        self.itssbm = Variable(name=StoichiTypeName.ITSSBM, default=StoichiDefaultValue.ITSSBM)
        self.fsi = Variable(name=StoichiTypeName.FSI, default=StoichiDefaultValue.FSI)
        self.yh = Variable(name=StoichiTypeName.YH, default=StoichiDefaultValue.YH)
        self.yaut = Variable(name=StoichiTypeName.YAUT, default=StoichiDefaultValue.YAUT)
        self.fxi = Variable(name=StoichiTypeName.FXI, default=StoichiDefaultValue.FXI)
        self.ypao = Variable(name=StoichiTypeName.YPAO, default=StoichiDefaultValue.YPAO)
        self.ypo = Variable(name=StoichiTypeName.YPO, default=StoichiDefaultValue.YPO)
        self.ypha = Variable(name=StoichiTypeName.YPHA, default=StoichiDefaultValue.YPHA)

    def update_by_t(self, t: float):
        self.icv.update_value_by_t(t)
        self.ivt.update_value_by_t(t)
        self.fbod.update_value_by_t(t)

        self.insi.update_value_by_t(t)
        self.insf.update_value_by_t(t)
        self.inxi.update_value_by_t(t)
        self.inxs.update_value_by_t(t)
        self.inbm.update_value_by_t(t)
        self.ipsi.update_value_by_t(t)
        self.ipsf.update_value_by_t(t)
        self.ipxi.update_value_by_t(t)
        self.ipxs.update_value_by_t(t)
        self.ipbm.update_value_by_t(t)

        self.itssxi.update_value_by_t(t)
        self.itssxs.update_value_by_t(t)
        self.itssbm.update_value_by_t(t)
        self.fsi.update_value_by_t(t)
        self.yh.update_value_by_t(t)
        self.yaut.update_value_by_t(t)
        self.fxi.update_value_by_t(t)
        self.ypao.update_value_by_t(t)
        self.ypo.update_value_by_t(t)
        self.ypha.update_value_by_t(t)