# -*- coding: utf-8 -*-
class Singleton(type):
    """单例元类"""

    # 重写call控制类对象的创建实现单例
    def __call__(cls, *args, **kwargs):
        # 如果cls没有_instance则为添加
        if not hasattr(cls, "_instance"):
            cls._instance = super().__call__(*args, **kwargs)
        # 如果cls._instance为None则为其添加
        if cls._instance is None:
            cls._instance = super().__call__(*args, **kwargs)
        return cls._instance
