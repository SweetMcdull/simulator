# -*- coding: utf-8 -*-
from modellibrary.src.main.python.core.tools.logger import Logger

log = Logger(__name__)


class Port:
    """模型端口"""

    def __init__(self, module, id, category):
        """
        模型端口构造函数
        :param module:所属模型
        :param id:端口唯一编号，字符串类型
        :param category:端口类型，PortType的枚举类型
        """
        self.id = id  # 唯一ID
        self.category = category  # 类型

        self.variables = []  # 绑定的变量集合，ASM2d模型应该是 1+19个
        self.__module = module  # 所属模型
        self.next = None  # 下一个端口

    @property
    def module(self):
        return self.__module

    def add_vars(self, var_list: list):
        """批量绑定变量"""
        self.variables.extend(var_list)

    def clear_vars(self):
        """清空变量"""
        self.variables.clear()

    def transfer_data(self, port):
        """端口变量值按顺序传递"""
        # log.logger.debug(f"{self.id}接受{port.id}的变量值传递")
        # 检查变量数量
        if not self.variables:
            raise RuntimeError('传输数据异常，本端口的变量数量为0')

        if not port.variables:
            raise RuntimeError('传输数据异常，传入端口的变量数量为0')

        # 判断变量数量是否一直
        if len(self.variables) != len(port.variables):
            raise RuntimeError('传输数据异常，本端口的变量数量不等于传入端口的变量数量')

        for target_var, source_var in zip(self.variables, port.variables):
            target_var.value = source_var.value

    def transfer_by_data(self, data: dict):
        """根据字典传递端口数据"""
        # 检查变量数量
        if not self.variables:
            raise RuntimeError('传输数据异常，本端口的变量数量为0')

        if not data:
            raise RuntimeError('传输数据异常，传入端口的变量数量为0')

        var_dict = {v.name: v for v in self.variables}
        if data.keys() != var_dict.keys():
            raise RuntimeError('传输数据异常，本端口的变量与传入端口的变量数据不一致')

        for v_name, v_value in data.items():
            var_obj = var_dict[v_name]
            var_obj.value = v_value
