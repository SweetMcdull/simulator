from .params.initialization import InitParams
from .params.physical import PhysicalParams
from .params.operation import OperationParams
from .params.takacs import TakacsParams
from ...params.stoichi import StoichiParams


class ParamSet:
    """参数集合"""

    def __init__(self):
        # 初始化参数
        self.initial = InitParams()
        # 物理参数
        self.physical = PhysicalParams()
        # 运行参数
        self.operation = OperationParams()
        # Takacs沉降动力学参数
        self.takacs = TakacsParams()
        # 化学计量学系数
        self.stoichi = StoichiParams()

    def update_by_t(self, t: float):
        self.initial.update_by_t(t)
        self.physical.update_by_t(t)
        self.operation.update_by_t(t)
        self.takacs.update_by_t(t)
        self.stoichi.update_by_t(t)
