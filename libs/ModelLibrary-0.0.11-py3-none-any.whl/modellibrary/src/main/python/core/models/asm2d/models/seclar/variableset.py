from modellibrary.src.main.python.core.common.variable import Variable
from modellibrary.src.main.python.core.models.asm2d.params.constants import VariableTypeName


class VariableSet:
    """变量集合"""

    def __init__(self, module):
        self.__module = module  # 所属模型
        # 流量变量
        self.flow_in = Variable(VariableTypeName.FLOW)
        self.flow_out = Variable(VariableTypeName.FLOW)
        self.flow_ras = Variable(VariableTypeName.FLOW)
        self.flow_was = Variable(VariableTypeName.FLOW)
        # 颗粒组分集合
        self.tss_list = []

        # 模型溶解性组分
        self.so = Variable(VariableTypeName.SO, is_save=True)
        self.sf = Variable(VariableTypeName.SF, is_save=True)
        self.sa = Variable(VariableTypeName.SA, is_save=True)
        self.snh = Variable(VariableTypeName.SNH, is_save=True)
        self.sno = Variable(VariableTypeName.SNO, is_save=True)
        self.spo = Variable(VariableTypeName.SPO, is_save=True)  # 磷酸盐
        self.si = Variable(VariableTypeName.SI, is_save=True)
        self.salk = Variable(VariableTypeName.SALK, is_save=True)  # 碱度
        self.snn = Variable(VariableTypeName.SNN, is_save=True)

        # 模块(出水)组分
        self.xi_out = Variable(VariableTypeName.XI, is_save=True)
        self.xs_out = Variable(VariableTypeName.XS, is_save=True)
        self.xh_out = Variable(VariableTypeName.XH, is_save=True)
        self.xpao_out = Variable(VariableTypeName.XPAO, is_save=True)
        self.xpp_out = Variable(VariableTypeName.XPP, is_save=True)
        self.xpha_out = Variable(VariableTypeName.XPHA, is_save=True)
        self.xaut_out = Variable(VariableTypeName.XAUT, is_save=True)
        self.xmeoh_out = Variable(VariableTypeName.XMEOH, is_save=True)  # 氢氧化铁
        self.xmep_out = Variable(VariableTypeName.XMEP, is_save=True)  # 磷酸铁
        self.xii_out = Variable(VariableTypeName.XII, is_save=True)

        # 模块(回流)组分
        self.xi_ras = Variable(VariableTypeName.XI)
        self.xs_ras = Variable(VariableTypeName.XS)
        self.xh_ras = Variable(VariableTypeName.XH)
        self.xpao_ras = Variable(VariableTypeName.XPAO)
        self.xpp_ras = Variable(VariableTypeName.XPP)
        self.xpha_ras = Variable(VariableTypeName.XPHA)
        self.xaut_ras = Variable(VariableTypeName.XAUT)
        self.xmeoh_ras = Variable(VariableTypeName.XMEOH)  # 氢氧化铁
        self.xmep_ras = Variable(VariableTypeName.XMEP)  # 磷酸铁
        self.xii_ras = Variable(VariableTypeName.XII)

        # 模块(排泥)组分
        self.xi_was = Variable(VariableTypeName.XI)
        self.xs_was = Variable(VariableTypeName.XS)
        self.xh_was = Variable(VariableTypeName.XH)
        self.xpao_was = Variable(VariableTypeName.XPAO)
        self.xpp_was = Variable(VariableTypeName.XPP)
        self.xpha_was = Variable(VariableTypeName.XPHA)
        self.xaut_was = Variable(VariableTypeName.XAUT)
        self.xmeoh_was = Variable(VariableTypeName.XMEOH)  # 氢氧化铁
        self.xmep_was = Variable(VariableTypeName.XMEP)  # 磷酸铁
        self.xii_was = Variable(VariableTypeName.XII)

        # 模块(进水)组分
        self.so_in = Variable(VariableTypeName.SO)
        self.sf_in = Variable(VariableTypeName.SF)
        self.sa_in = Variable(VariableTypeName.SA)
        self.snh_in = Variable(VariableTypeName.SNH)
        self.sno_in = Variable(VariableTypeName.SNO)
        self.spo_in = Variable(VariableTypeName.SPO)  # 磷酸盐
        self.si_in = Variable(VariableTypeName.SI)
        self.salk_in = Variable(VariableTypeName.SALK)  # 碱度
        self.snn_in = Variable(VariableTypeName.SNN)
        self.xi_in = Variable(VariableTypeName.XI)
        self.xs_in = Variable(VariableTypeName.XS)
        self.xh_in = Variable(VariableTypeName.XH)
        self.xpao_in = Variable(VariableTypeName.XPAO)
        self.xpp_in = Variable(VariableTypeName.XPP)
        self.xpha_in = Variable(VariableTypeName.XPHA)
        self.xaut_in = Variable(VariableTypeName.XAUT)
        self.xmeoh_in = Variable(VariableTypeName.XMEOH)  # 氢氧化铁
        self.xmep_in = Variable(VariableTypeName.XMEP)  # 磷酸铁
        self.xii_in = Variable(VariableTypeName.XII)

        # 顶层复合指标
        self.cod_top = Variable(VariableTypeName.COD)
        self.bod_top = Variable(VariableTypeName.BOD)
        self.tss_top = Variable(VariableTypeName.TSS)
        self.tn_top = Variable(VariableTypeName.TN)
        self.tp_top = Variable(VariableTypeName.TP)
        # 底层复合指标
        self.cod_bottom = Variable(VariableTypeName.COD)
        self.bod_bottom = Variable(VariableTypeName.BOD)
        self.tss_bottom = Variable(VariableTypeName.TSS)
        self.tn_bottom = Variable(VariableTypeName.TN)
        self.tp_bottom = Variable(VariableTypeName.TP)

        self.set = {
            'flow_in': self.flow_in,
            'flow_out': self.flow_out,
            'flow_ras': self.flow_ras,
            'flow_was': self.flow_was,
            'so': self.so,
            'sf': self.sf,
            'sa': self.sa,
            'snh': self.snh,
            'sno': self.sno,
            'spo': self.spo,
            'si': self.si,
            'salk': self.salk,
            'snn': self.snn,
            'xi_out': self.xi_out,
            'xs_out': self.xs_out,
            'xh_out': self.xh_out,
            'xpao_out': self.xpao_out,
            'xpp_out': self.xpp_out,
            'xpha_out': self.xpha_out,
            'xaut_out': self.xaut_out,
            'xmeoh_out': self.xmeoh_out,
            'xmep_out': self.xmep_out,
            'xii_out': self.xii_out,
            'xi_ras': self.xi_ras,
            'xs_ras': self.xs_ras,
            'xh_ras': self.xh_ras,
            'xpao_ras': self.xpao_ras,
            'xpp_ras': self.xpp_ras,
            'xpha_ras': self.xpha_ras,
            'xaut_ras': self.xaut_ras,
            'xmeoh_ras': self.xmeoh_ras,
            'xmep_ras': self.xmep_ras,
            'xii_ras': self.xii_ras,
            'xi_was': self.xi_was,
            'xs_was': self.xs_was,
            'xh_was': self.xh_was,
            'xpao_was': self.xpao_was,
            'xpp_was': self.xpp_was,
            'xpha_was': self.xpha_was,
            'xaut_was': self.xaut_was,
            'xmeoh_was': self.xmeoh_was,
            'xmep_was': self.xmep_was,
            'xii_was': self.xii_was,
            'so_in': self.so_in,
            'sf_in': self.sf_in,
            'sa_in': self.sa_in,
            'snh_in': self.snh_in,
            'sno_in': self.sno_in,
            'spo_in': self.spo_in,
            'si_in': self.si_in,
            'salk_in': self.salk_in,
            'snn_in': self.snn_in,
            'xi_in': self.xi_in,
            'xs_in': self.xs_in,
            'xh_in': self.xh_in,
            'xpao_in': self.xpao_in,
            'xpp_in': self.xpp_in,
            'xpha_in': self.xpha_in,
            'xaut_in': self.xaut_in,
            'xmeoh_in': self.xmeoh_in,
            'xmep_in': self.xmep_in,
            'xii_in': self.xii_in,
            'cod_top': self.cod_top,
            'bod_top': self.bod_top,
            'tss_top': self.tss_top,
            'tn_top': self.tn_top,
            'tp_top': self.tp_top,
            'cod_bottom': self.cod_bottom,
            'bod_bottom': self.bod_bottom,
            'tss_bottom': self.tss_bottom,
            'tn_bottom': self.tn_bottom,
            'tp_bottom': self.tp_bottom,
        }

    @property
    def denseness(self):
        denseness_s = [self.so.value,
                       self.sf.value,
                       self.sa.value,
                       self.snh.value,
                       self.sno.value,
                       self.spo.value,
                       self.si.value,
                       self.salk.value,
                       self.snn.value]
        denseness_tss = [tss.value for tss in self.tss_list]
        return denseness_s + denseness_tss

    @property
    def denseness_in(self):
        """进水组分浓度"""
        return [self.so_in.value,
                self.sf_in.value,
                self.sa_in.value,
                self.snh_in.value,
                self.sno_in.value,
                self.spo_in.value,
                self.si_in.value,
                self.salk_in.value,
                self.snn_in.value,
                self.xi_in.value,
                self.xs_in.value,
                self.xh_in.value,
                self.xpao_in.value,
                self.xpp_in.value,
                self.xpha_in.value,
                self.xaut_in.value,
                self.xmeoh_in.value,
                self.xmep_in.value,
                self.xii_in.value]

    def get_port_in_vars(self):
        """进水变量集合"""
        return [self.flow_in,
                self.so_in,
                self.sf_in,
                self.sa_in,
                self.snh_in,
                self.sno_in,
                self.spo_in,
                self.si_in,
                self.salk_in,
                self.snn_in,
                self.xi_in,
                self.xs_in,
                self.xh_in,
                self.xpao_in,
                self.xpp_in,
                self.xpha_in,
                self.xaut_in,
                self.xmeoh_in,
                self.xmep_in,
                self.xii_in]

    def get_port_out_vars(self):
        """出水变量集合"""
        return [self.flow_out,
                self.so,
                self.sf,
                self.sa,
                self.snh,
                self.sno,
                self.spo,
                self.si,
                self.salk,
                self.snn,
                self.xi_out,
                self.xs_out,
                self.xh_out,
                self.xpao_out,
                self.xpp_out,
                self.xpha_out,
                self.xaut_out,
                self.xmeoh_out,
                self.xmep_out,
                self.xii_out]

    def get_port_ras_vars(self):
        """抽水变量集合"""
        return [self.flow_ras,
                self.so,
                self.sf,
                self.sa,
                self.snh,
                self.sno,
                self.spo,
                self.si,
                self.salk,
                self.snn,
                self.xi_ras,
                self.xs_ras,
                self.xh_ras,
                self.xpao_ras,
                self.xpp_ras,
                self.xpha_ras,
                self.xaut_ras,
                self.xmeoh_ras,
                self.xmep_ras,
                self.xii_ras]

    def get_port_was_vars(self):
        """排泥变量集合"""
        return [self.flow_was,
                self.so,
                self.sf,
                self.sa,
                self.snh,
                self.sno,
                self.spo,
                self.si,
                self.salk,
                self.snn,
                self.xi_was,
                self.xs_was,
                self.xh_was,
                self.xpao_was,
                self.xpp_was,
                self.xpha_was,
                self.xaut_was,
                self.xmeoh_was,
                self.xmep_was,
                self.xii_was]

    def init_tss(self):
        total_layer = self.__module.params.physical.total_layer.value
        param_tss_list = self.__module.params.initial.tss_list
        self.tss_list.clear()  # 清除
        for i in range(total_layer):
            self.tss_list.append(Variable(VariableTypeName.TSS, default=param_tss_list[i].value))
