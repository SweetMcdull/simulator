# -*- coding: utf-8 -*-
from typing import Optional, List
import numpy as np


class Variable:
    """变量类"""

    def __init__(
            self,
            name: str,
            default=0.,
            is_save: bool = False,
            unit: Optional[str] = 'mg/l',
            max_range: float = 0.,
            min_range: float = 0.,
            can_be_seq: bool = False,
            is_sequence: bool = False,
            sequence=None):
        self.name = name  # 变量名
        self.default = default  # 初始值
        self._value = default  # 变量当前值
        self.is_save = is_save  # 是否保存
        self.unit = unit  # 单位
        self.max_range = max_range  # 最大量程
        self.min_range = min_range  # 最小量程

        self.can_be_seq = can_be_seq  # 是否能为时序值
        self.is_sequence = is_sequence  # 是否为时间序列
        self.sequence = sequence  # 时间序列值

        self.results = None  # 结果

    @property
    def value(self):
        return self._value

    @value.setter
    def value(self, value):
        if value < 0:
            self._value = 0
        else:
            self._value = value

    def append_result(self, index, value):
        self.results[index] = round(value, 3)

    def init_result(self, times):
        self.results = np.zeros(times)
        self.results[0] = 0

    def update_value_by_t(self, t: float):
        seq = self.sequence
        if self.is_sequence and seq:
            unit_count = len(seq)  # 总共有几天/小时

            count = len(seq[0])  # 每天/小时有多少个点

            unit_index = int(t % unit_count) + 1  # 判断是第几天/小时,根据提供的序列循环
            residue = round(t % 1, 2)  # 取小数部分,保留两位小数
            data_index = int(residue * count)  # 获取t对应数据的索引值

            if unit_index >= unit_count:  # 如果超过了最大单位则取最后一个单位的数据
                data = seq[-1]
            else:
                data = seq[unit_index]

            self.value = data[data_index]

    def __str__(self):
        return f"{self.name}:{self.value}"

    def __repr__(self):
        return f"{self.name}:{self.value}"


if __name__ == '__main__':
    day_seq = [
        [
            1000,
            2000,
            3000,
            4000,
            5000,
            6000,
            7000,
            8000,
            9000,
            10000,
            11000,
            12000,
            13000,
            14000,
            15000,
            16000,
            17000,
            18000,
            19000,
            20000,
            21000,
            22000,
            23000,
            24000
        ],
        [
            1001,
            2002,
            3003,
            4004,
            5005,
            6006,
            7007,
            8008,
            9009,
            10010,
            11011,
            12012,
            13013,
            14014,
            15015,
            16016,
            17017,
            18018,
            19019,
            20020,
            21021,
            22022,
            23023,
            24024
        ]
    ]
    hour_seq = [
        [1000, 2000, 3000, 4000, 5000, 6000],
        [1001, 2002, 3003, 4004, 5005, 6006],
    ]
    v = Variable(name='test', is_sequence=True, sequence=hour_seq)
    v.update_value_by_t(0)
    print(v.value)
