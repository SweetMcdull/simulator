# -*- coding: utf-8 -*-
import os

import matplotlib.pyplot as plt
import numpy as np

from modellibrary.src.main.python.core.algorithm.arithmetic import Arithmetic
from modellibrary.src.main.python.core.algorithm.process import Process
from modellibrary.src.main.python.core.models.asm2d.params.constants import ModuleType
from modellibrary.src.main.python.core.models.factory.modelfactory import ModelFactory
from modellibrary.src.main.python.core.tools.logger import Logger

from modellibrary.tests.public.public import before_ode_fun, after_ode_fun

log = Logger(__name__)


def drawing(start, terminal, interval, module_id):
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    count = int((terminal - start) / interval) + 1
    t_sequence = np.linspace(start, terminal, count)

    module = process.get_module(module_id)

    if module.category == ModuleType.REACTION_MODULE:
        plt.subplot(2, 2, 1)
        plt.title("流量")
        plt.xlabel("仿真时间（天）")
        plt.ylabel("流量")
        in_flow = module.variables.flow_in.results
        out_flow = module.variables.flow_out.results
        pump_flow = module.variables.flow_pump.results
        converge_flow = module.variables.flow_converge.results
        plt.plot(t_sequence, in_flow, "r", label="in_flow")
        plt.plot(t_sequence, out_flow, "b", label="out_flow")
        plt.plot(t_sequence, pump_flow, "y", label="pump_flow")
        plt.plot(t_sequence, converge_flow, "c", label="converge_flow")
        plt.legend()
        plt.subplot(2, 2, 2)
        plt.title("组分")
        plt.xlabel("仿真时间（天）")
        plt.ylabel("组分")
        so = module.variables.so.results
        sno = module.variables.sno.results
        snh = module.variables.snh.results
        spo = module.variables.spo.results
        plt.plot(t_sequence, so, color="r", label="so")
        plt.plot(t_sequence, sno, "b", label="sno")
        plt.plot(t_sequence, snh, "y", label="snh")
        plt.plot(t_sequence, spo, "c", label="spo")
        plt.legend()

        plt.subplot(2, 2, 3)
        plt.title("复合指标")
        plt.xlabel("仿真时间（天）")
        plt.ylabel("复合指标")
        cod = module.variables.cod.results
        bod = module.variables.bod.results
        tss = module.variables.tss.results
        tn = module.variables.tn.results
        tp = module.variables.tp.results
        plt.plot(t_sequence, cod, color="r", label="cod")
        plt.plot(t_sequence, bod, "b", label="bod")
        plt.plot(t_sequence, tss, "y", label="tss")
        plt.plot(t_sequence, tn, "c", label="tn")
        plt.plot(t_sequence, tp, "g", label="tp")
        plt.legend()
    elif module.category == ModuleType.INFLOW_MODULE:
        plt.subplot(2, 2, 1)
        plt.title("流量")
        plt.xlabel("仿真时间（天）")
        plt.ylabel("流量")
        out_flow = module.variables.flow_out.results
        plt.plot(t_sequence, out_flow, "b", label="out_flow")
        plt.legend()
        plt.subplot(2, 2, 2)
        plt.title("组分")
        plt.xlabel("仿真时间（天）")
        plt.ylabel("组分")
        spo = module.variables.spo.results
        salk = module.variables.salk.results
        xmeoh = module.variables.xmeoh.results
        xmep = module.variables.xmep.results
        plt.plot(t_sequence, spo, color="r", label="spo")
        plt.plot(t_sequence, salk, "b", label="salk")
        plt.plot(t_sequence, xmeoh, "y", label="xmeoh")
        plt.plot(t_sequence, xmep, "c", label="xmep")
        plt.legend()

        plt.subplot(2, 2, 3)
        plt.title("复合指标")
        plt.xlabel("仿真时间（天）")
        plt.ylabel("复合指标")
        cod = module.variables.cod.results
        bod = module.variables.bod.results
        tss = module.variables.tss.results
        tn = module.variables.tn.results
        tp = module.variables.tp.results
        plt.plot(t_sequence, cod, color="r", label="cod")
        plt.plot(t_sequence, bod, "b", label="bod")
        plt.plot(t_sequence, tss, "y", label="tss")
        plt.plot(t_sequence, tn, "c", label="tn")
        plt.plot(t_sequence, tp, "g", label="tp")
        plt.legend()
    elif module.category == ModuleType.SECLAR_MODULE:
        plt.subplot(2, 2, 1)
        plt.title("流量")
        plt.xlabel("仿真时间（天）")
        plt.ylabel("流量")
        in_flow = module.variables.flow_in.results
        out_flow = module.variables.flow_out.results
        ras_flow = module.variables.flow_ras.results
        was_flow = module.variables.flow_was.results
        plt.plot(t_sequence, in_flow, "r", label="in_flow")
        plt.plot(t_sequence, out_flow, "b", label="out_flow")
        plt.plot(t_sequence, ras_flow, "y", label="ras_flow")
        plt.plot(t_sequence, was_flow, "c", label="was_flow")
        plt.legend()

        plt.subplot(2, 2, 2)
        plt.title("组分")
        plt.xlabel("仿真时间（天）")
        plt.ylabel("组分")
        so = module.variables.so.results
        sf = module.variables.sf.results
        sa = module.variables.sa.results
        snh = module.variables.snh.results
        plt.plot(t_sequence, so, color="r", label="spo")
        plt.plot(t_sequence, sf, "b", label="salk")
        plt.plot(t_sequence, sa, "y", label="xmeoh")
        plt.plot(t_sequence, snh, "c", label="xmep")
        plt.legend()

        plt.subplot(2, 2, 3)
        plt.title("每层颗粒")
        plt.xlabel("仿真时间（天）")
        plt.ylabel("每层颗粒")
        tss_top = module.variables.tss_list[0].results
        tss_bottom = module.variables.tss_list[-1].results
        plt.plot(t_sequence, tss_top, color="r", label="tss_top")
        plt.plot(t_sequence, tss_bottom, "b", label="tss_bottom")
        plt.legend()

        plt.subplot(2, 2, 4)
        plt.title("每层颗粒")
        plt.xlabel("仿真时间（天）")
        plt.ylabel("每层颗粒")
        xi_ras = module.variables.xi_ras.results
        xs_ras = module.variables.xs_ras.results
        xh_ras = module.variables.xh_ras.results
        xpao_ras = module.variables.xpao_ras.results
        plt.plot(t_sequence, xi_ras, color="r", label="xi_ras")
        plt.plot(t_sequence, xs_ras, "b", label="xs_ras")
        plt.plot(t_sequence, xh_ras, "y", label="xh_ras")
        plt.plot(t_sequence, xpao_ras, "c", label="xpao_ras")
        plt.legend()

    plt.suptitle(module.id)
    # plt.legend()
    plt.show()


if __name__ == '__main__':
    # 1. 构造流程对象
    process = Process()
    process.use_init_value = True  # 开启将上一次仿真结果当做本次方针初始值

    # 2.从模型工厂中构造模型
    inf_module = ModelFactory.create_model_by_name(ModelFactory.Inflow, "inf")
    # 厌氧区，建模过程中作为三个独立的单元（CSTR）
    anaerobic_1 = ModelFactory.create_model_by_name(ModelFactory.CSTR, "anaerobic_1")
    anaerobic_2 = ModelFactory.create_model_by_name(ModelFactory.CSTR, "anaerobic_2")
    anaerobic_3 = ModelFactory.create_model_by_name(ModelFactory.CSTR, "anaerobic_3")
    # 第一缺氧区，建模过程中划分为三个独立的单元（CSTR）
    first_anoxia_1 = ModelFactory.create_model_by_name(ModelFactory.CSTR, "first_anoxia_1")
    first_anoxia_2 = ModelFactory.create_model_by_name(ModelFactory.CSTR, "first_anoxia_2")
    first_anoxia_3 = ModelFactory.create_model_by_name(ModelFactory.CSTR, "first_anoxia_3")
    # 第一好氧区，建模过程中划分为六个独立的单元（CSTR）
    first_aerobic_1 = ModelFactory.create_model_by_name(ModelFactory.CSTR, "first_aerobic_1")
    first_aerobic_2 = ModelFactory.create_model_by_name(ModelFactory.CSTR, "first_aerobic_2")
    first_aerobic_3 = ModelFactory.create_model_by_name(ModelFactory.CSTR, "first_aerobic_3")
    first_aerobic_4 = ModelFactory.create_model_by_name(ModelFactory.CSTR, "first_aerobic_4")
    first_aerobic_5 = ModelFactory.create_model_by_name(ModelFactory.CSTR, "first_aerobic_5")
    first_aerobic_6 = ModelFactory.create_model_by_name(ModelFactory.CSTR, "first_aerobic_6")

    # 第二缺氧区，建模过程中划分为三个独立的单元（CSTR）
    second_anoxia_1 = ModelFactory.create_model_by_name(ModelFactory.CSTR, "second_anoxia_1")
    second_anoxia_2 = ModelFactory.create_model_by_name(ModelFactory.CSTR, "second_anoxia_2")
    second_anoxia_3 = ModelFactory.create_model_by_name(ModelFactory.CSTR, "second_anoxia_3")
    # 第二好氧区，建模过程中划分为六个独立的单元（CSTR）
    second_aerobic_1 = ModelFactory.create_model_by_name(ModelFactory.CSTR, "second_aerobic_1")
    second_aerobic_2 = ModelFactory.create_model_by_name(ModelFactory.CSTR, "second_aerobic_2")
    second_aerobic_3 = ModelFactory.create_model_by_name(ModelFactory.CSTR, "second_aerobic_3")
    second_aerobic_4 = ModelFactory.create_model_by_name(ModelFactory.CSTR, "second_aerobic_4")
    second_aerobic_5 = ModelFactory.create_model_by_name(ModelFactory.CSTR, "second_aerobic_5")
    second_aerobic_6 = ModelFactory.create_model_by_name(ModelFactory.CSTR, "second_aerobic_6")
    # 沉淀池
    seclar = ModelFactory.create_model_by_name(ModelFactory.SECLAR, "seclar")

    anaerobic_1.params.operation.q_air.value = 0.
    anaerobic_2.params.operation.q_air.value = 0.
    anaerobic_3.params.operation.q_air.value = 0.
    first_anoxia_1.params.operation.q_air.value = 0.
    first_anoxia_2.params.operation.q_air.value = 0.
    first_anoxia_3.params.operation.q_air.value = 0.
    first_aerobic_1.params.operation.q_air.value = 0.
    first_aerobic_2.params.operation.q_air.value = 0.
    first_aerobic_3.params.operation.q_air.value = 0.
    first_aerobic_4.params.operation.q_air.value = 0.
    first_aerobic_5.params.operation.q_air.value = 0.
    first_aerobic_6.params.operation.q_air.value = 0.
    second_anoxia_1.params.operation.q_air.value = 0.
    second_anoxia_2.params.operation.q_air.value = 0.
    second_anoxia_3.params.operation.q_air.value = 0.
    second_aerobic_1.params.operation.q_air.value = 0.
    second_aerobic_2.params.operation.q_air.value = 0.
    second_aerobic_3.params.operation.q_air.value = 0.
    second_aerobic_4.params.operation.q_air.value = 0.
    second_aerobic_5.params.operation.q_air.value = 0.
    second_aerobic_6.params.operation.q_air.value = 0.

    # 批量设置模型参数
    inf_module.set_params({
        "inflow": {
            "flow": {
                "value": 2000,
                "is_sequence": True,
                "sequence": [
                    [
                        2000,
                        3000,
                        2000,
                        2500,
                        2500,
                        3000,
                        2000,
                        3000,
                        2000,
                        2500,
                        2500,
                        3000,
                        2000,
                        3000,
                        2000,
                        2500,
                        2500,
                        3000,
                        2000,
                        3000,
                        2000,
                        2500,
                        2500,
                        3000,
                    ],
                    [
                        3000,
                        4000,
                        3000,
                        3500,
                        3500,
                        4000,
                        3000,
                        4000,
                        3000,
                        3500,
                        3500,
                        4000,
                        3000,
                        4000,
                        3000,
                        4500,
                        3500,
                        4000,
                        3000,
                        4000,
                        3000,
                        3500,
                        3500,
                        4000,
                    ]
                ]
            },
            "so": {
                "value": 0
            },
            "sf": {
                "value": 0
            },
            "sa": {
                "value": 0
            },
            "snh": {
                "value": 25
            },
            "sno": {
                "value": 0
            },
            "spo": {
                "value": 10
            },
            "si": {
                "value": 30
            },
            "salk": {
                "value": 7
            },
            "snn": {
                "value": 0
            },
            "xi": {
                "value": 130
            },
            "xs": {
                "value": 100
            },
            "xh": {
                "value": 0
            },
            "xpao": {
                "value": 0
            },
            "xpp": {
                "value": 0
            },
            "xpha": {
                "value": 0
            },
            "xaut": {
                "value": 0
            },
            "xmeoh": {
                "value": 0
            },
            "xmep": {
                "value": 0
            },
            "xii": {
                "value": 30
            }
        }}
    )

    # 3.载入模型到process
    modules = [inf_module,
               anaerobic_1, anaerobic_2, anaerobic_3,
               first_anoxia_1, first_anoxia_2, first_anoxia_3,
               first_aerobic_1, first_aerobic_2, first_aerobic_3, first_aerobic_4, first_aerobic_5, first_aerobic_6,
               second_anoxia_1, second_anoxia_2, second_anoxia_3,
               second_aerobic_1, second_aerobic_2, second_aerobic_3, second_aerobic_4, second_aerobic_5,
               second_aerobic_6,
               seclar]
    process.load_modules(modules)

    # 4.构造模型间的连接关系
    # 进水与厌氧区
    process.append_connect(inf_module, inf_module.ports.out_port, anaerobic_1, anaerobic_1.ports.in_port)
    process.append_connect(anaerobic_1, anaerobic_1.ports.out_port, anaerobic_2, anaerobic_2.ports.in_port)
    process.append_connect(anaerobic_2, anaerobic_2.ports.out_port, anaerobic_3, anaerobic_3.ports.in_port)
    # 厌氧区与第一缺氧区
    process.append_connect(anaerobic_3, anaerobic_3.ports.out_port, first_anoxia_1, first_anoxia_1.ports.in_port)
    process.append_connect(first_anoxia_1, first_anoxia_1.ports.out_port, first_anoxia_2, first_anoxia_2.ports.in_port)
    process.append_connect(first_anoxia_2, first_anoxia_2.ports.out_port, first_anoxia_3, first_anoxia_3.ports.in_port)
    # 第一缺氧区与第一好氧区
    process.append_connect(first_anoxia_3, first_anoxia_3.ports.out_port, first_aerobic_1,
                           first_aerobic_1.ports.in_port)
    process.append_connect(first_aerobic_1, first_aerobic_1.ports.out_port, first_aerobic_2,
                           first_aerobic_2.ports.in_port)
    process.append_connect(first_aerobic_2, first_aerobic_2.ports.out_port, first_aerobic_3,
                           first_aerobic_3.ports.in_port)
    process.append_connect(first_aerobic_3, first_aerobic_3.ports.out_port, first_aerobic_4,
                           first_aerobic_4.ports.in_port)
    process.append_connect(first_aerobic_4, first_aerobic_4.ports.out_port, first_aerobic_5,
                           first_aerobic_5.ports.in_port)
    process.append_connect(first_aerobic_5, first_aerobic_5.ports.out_port, first_aerobic_6,
                           first_aerobic_6.ports.in_port)
    # 第一好氧区与第二缺氧区
    process.append_connect(first_aerobic_6, first_aerobic_6.ports.out_port, second_anoxia_1,
                           second_anoxia_1.ports.in_port)
    process.append_connect(second_anoxia_1, second_anoxia_1.ports.out_port, second_anoxia_2,
                           second_anoxia_2.ports.in_port)
    process.append_connect(second_anoxia_2, second_anoxia_2.ports.out_port, second_anoxia_3,
                           second_anoxia_3.ports.in_port)
    # 第二缺氧区与第二好氧区
    process.append_connect(second_anoxia_3, second_anoxia_3.ports.out_port, second_aerobic_1,
                           second_aerobic_1.ports.in_port)
    process.append_connect(second_aerobic_1, second_aerobic_1.ports.out_port, second_aerobic_2,
                           second_aerobic_2.ports.in_port)
    process.append_connect(second_aerobic_2, second_aerobic_2.ports.out_port, second_aerobic_3,
                           second_aerobic_3.ports.in_port)
    process.append_connect(second_aerobic_3, second_aerobic_3.ports.out_port, second_aerobic_4,
                           second_aerobic_4.ports.in_port)
    process.append_connect(second_aerobic_4, second_aerobic_4.ports.out_port, second_aerobic_5,
                           second_aerobic_5.ports.in_port)
    process.append_connect(second_aerobic_5, second_aerobic_5.ports.out_port, second_aerobic_6,
                           second_aerobic_6.ports.in_port)

    # 第二好氧区与沉淀池
    process.append_connect(second_aerobic_6, second_aerobic_6.ports.out_port, seclar, seclar.ports.in_port)

    # 沉淀池向厌氧区第一个cstr回流
    process.append_connect(seclar, seclar.ports.ras_port, anaerobic_1, anaerobic_1.ports.converge_port)
    # 第二好氧区末端对第一缺氧区进行回流
    process.append_connect(second_aerobic_6, second_aerobic_6.ports.pump_port, first_anoxia_1,
                           first_anoxia_1.ports.converge_port)

    # 5.求解方程
    start = 0
    terminal = 1
    interval = 0.01
    ar = Arithmetic(process=process, start=start, terminal=terminal, interval=interval)

    ar.solve(before_ode_fun=before_ode_fun, after_ode_fun=after_ode_fun)
    ar.save_result()
    base_dir = os.path.dirname(os.path.abspath(__file__))
    results_path = os.path.join(base_dir, 'results')
    if not os.path.exists(results_path):
        if not os.path.isdir(results_path):
            os.mkdir(results_path)
    np.savetxt('results.txt', ar.result_test, fmt="%.5f", delimiter=",")

    # 5.绘图
    # 一个反应池一个图
    drawing(start, terminal, interval, "inf")
    drawing(start, terminal, interval, "seclar")
    drawing(start, terminal, interval, "anaerobic_1")
    drawing(start, terminal, interval, "second_aerobic_6")
