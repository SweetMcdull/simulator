# -*- coding: utf-8 -*-
import os

import matplotlib.pyplot as plt
import numpy as np

from modellibrary.src.main.python.core.algorithm.arithmetic import Arithmetic
from modellibrary.src.main.python.core.algorithm.process import Process
from modellibrary.src.main.python.core.models.asm2d.params.constants import ModuleType
from modellibrary.src.main.python.core.models.factory.modelfactory import ModelFactory
from modellibrary.src.main.python.core.tools.logger import Logger

from modellibrary.tests.public.public import before_ode_fun, after_ode_fun

log = Logger(__name__)


def drawing(start, terminal, interval, module_id):
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    count = int((terminal - start) / interval) + 1
    t_sequence = np.linspace(start, terminal, count)

    module = process.get_module(module_id)

    if module.category == ModuleType.REACTION_MODULE:
        plt.subplot(2, 2, 1)
        plt.title("流量")
        plt.xlabel("仿真时间（天）")
        plt.ylabel("流量")
        in_flow = module.variables.flow_in.results
        out_flow = module.variables.flow_out.results
        pump_flow = module.variables.flow_pump.results
        converge_flow = module.variables.flow_converge.results
        plt.plot(t_sequence, in_flow, "r", label="in_flow")
        plt.plot(t_sequence, out_flow, "b", label="out_flow")
        plt.plot(t_sequence, pump_flow, "y", label="pump_flow")
        plt.plot(t_sequence, converge_flow, "c", label="converge_flow")
        plt.legend()
        plt.subplot(2, 2, 2)
        plt.title("组分")
        plt.xlabel("仿真时间（天）")
        plt.ylabel("组分")
        spo = module.variables.spo.results
        salk = module.variables.salk.results
        xmeoh = module.variables.xmeoh.results
        xmep = module.variables.xmep.results
        plt.plot(t_sequence, spo, color="r", label="spo")
        plt.plot(t_sequence, salk, "b", label="salk")
        plt.plot(t_sequence, xmeoh, "y", label="xmeoh")
        plt.plot(t_sequence, xmep, "c", label="xmep")
        plt.legend()

        plt.subplot(2, 2, 3)
        plt.title("复合指标")
        plt.xlabel("仿真时间（天）")
        plt.ylabel("复合指标")
        cod = module.variables.cod.results
        bod = module.variables.bod.results
        tss = module.variables.tss.results
        tn = module.variables.tn.results
        tp = module.variables.tp.results
        plt.plot(t_sequence, cod, color="r", label="cod")
        plt.plot(t_sequence, bod, "b", label="bod")
        plt.plot(t_sequence, tss, "y", label="tss")
        plt.plot(t_sequence, tn, "c", label="tn")
        plt.plot(t_sequence, tp, "g", label="tp")
        plt.legend()
    elif module.category == ModuleType.INFLOW_MODULE:
        plt.subplot(2, 2, 1)
        plt.title("流量")
        plt.xlabel("仿真时间（天）")
        plt.ylabel("流量")
        out_flow = module.variables.flow_out.results
        plt.plot(t_sequence, out_flow, "b", label="out_flow")
        plt.legend()
        plt.subplot(2, 2, 2)
        plt.title("组分")
        plt.xlabel("仿真时间（天）")
        plt.ylabel("组分")
        spo = module.variables.spo.results
        salk = module.variables.salk.results
        xmeoh = module.variables.xmeoh.results
        xmep = module.variables.xmep.results
        plt.plot(t_sequence, spo, color="r", label="spo")
        plt.plot(t_sequence, salk, "b", label="salk")
        plt.plot(t_sequence, xmeoh, "y", label="xmeoh")
        plt.plot(t_sequence, xmep, "c", label="xmep")
        plt.legend()

        plt.subplot(2, 2, 3)
        plt.title("复合指标")
        plt.xlabel("仿真时间（天）")
        plt.ylabel("复合指标")
        cod = module.variables.cod.results
        bod = module.variables.bod.results
        tss = module.variables.tss.results
        tn = module.variables.tn.results
        tp = module.variables.tp.results
        plt.plot(t_sequence, cod, color="r", label="cod")
        plt.plot(t_sequence, bod, "b", label="bod")
        plt.plot(t_sequence, tss, "y", label="tss")
        plt.plot(t_sequence, tn, "c", label="tn")
        plt.plot(t_sequence, tp, "g", label="tp")
        plt.legend()
    elif module.category == ModuleType.SECLAR_MODULE:
        plt.subplot(2, 2, 1)
        plt.title("流量")
        plt.xlabel("仿真时间（天）")
        plt.ylabel("流量")
        in_flow = module.variables.flow_in.results
        out_flow = module.variables.flow_out.results
        ras_flow = module.variables.flow_ras.results
        was_flow = module.variables.flow_was.results
        plt.plot(t_sequence, in_flow, "r", label="in_flow")
        plt.plot(t_sequence, out_flow, "b", label="out_flow")
        plt.plot(t_sequence, ras_flow, "y", label="ras_flow")
        plt.plot(t_sequence, was_flow, "c", label="was_flow")
        plt.legend()

        plt.subplot(2, 2, 2)
        plt.title("组分")
        plt.xlabel("仿真时间（天）")
        plt.ylabel("组分")
        so = module.variables.so.results
        sf = module.variables.sf.results
        sa = module.variables.sa.results
        snh = module.variables.snh.results
        plt.plot(t_sequence, so, color="r", label="spo")
        plt.plot(t_sequence, sf, "b", label="salk")
        plt.plot(t_sequence, sa, "y", label="xmeoh")
        plt.plot(t_sequence, snh, "c", label="xmep")
        plt.legend()

        plt.subplot(2, 2, 3)
        plt.title("每层颗粒")
        plt.xlabel("仿真时间（天）")
        plt.ylabel("每层颗粒")
        tss_top = module.variables.tss_list[0].results
        tss_bottom = module.variables.tss_list[-1].results
        plt.plot(t_sequence, tss_top, color="r", label="tss_top")
        plt.plot(t_sequence, tss_bottom, "b", label="tss_bottom")
        plt.legend()

        plt.subplot(2, 2, 4)
        plt.title("每层颗粒")
        plt.xlabel("仿真时间（天）")
        plt.ylabel("每层颗粒")
        xi_ras = module.variables.xi_ras.results
        xs_ras = module.variables.xs_ras.results
        xh_ras = module.variables.xh_ras.results
        xpao_ras = module.variables.xpao_ras.results
        plt.plot(t_sequence, xi_ras, color="r", label="xi_ras")
        plt.plot(t_sequence, xs_ras, "b", label="xs_ras")
        plt.plot(t_sequence, xh_ras, "y", label="xh_ras")
        plt.plot(t_sequence, xpao_ras, "c", label="xpao_ras")
        plt.legend()

    plt.suptitle(module.id)
    # plt.legend()
    plt.show()


if __name__ == '__main__':
    # 1. 构造流程对象
    process = Process()
    process.use_init_value = True  # 开启将上一次仿真结果当做本次方针初始值

    # 2.从模型工厂中构造模型
    inf_module = ModelFactory.create_model_by_name(ModelFactory.Inflow, "inf")
    cstr_1 = ModelFactory.create_model_by_name(ModelFactory.CSTR, "1#")
    cstr_2 = ModelFactory.create_model_by_name(ModelFactory.CSTR, "2#")
    cstr_3 = ModelFactory.create_model_by_name(ModelFactory.CSTR, "3#")
    seclar = ModelFactory.create_model_by_name(ModelFactory.SECLAR, "seclar")

    # 批量设置模型参数
    inf_module.set_params({
        "inflow": {
            "flow": {
                "value": 1000,
                "is_sequence": True,
                "sequence": [
                    [
                        2000,
                        2000,
                        3000,
                        4000,
                        5000,
                        6000
                    ],
                    [
                        1001,
                        2002,
                        3003,
                        4004,
                        5005,
                        6006
                    ]
                ]
            },
            "so": {
                "value": 0
            },
            "sf": {
                "value": 0
            },
            "sa": {
                "value": 0
            },
            "snh": {
                "value": 25
            },
            "sno": {
                "value": 0
            },
            "spo": {
                "value": 10
            },
            "si": {
                "value": 30
            },
            "salk": {
                "value": 7
            },
            "snn": {
                "value": 0
            },
            "xi": {
                "value": 130
            },
            "xs": {
                "value": 100
            },
            "xh": {
                "value": 0
            },
            "xpao": {
                "value": 0
            },
            "xpp": {
                "value": 0
            },
            "xpha": {
                "value": 0
            },
            "xaut": {
                "value": 0
            },
            "xmeoh": {
                "value": 0
            },
            "xmep": {
                "value": 0
            },
            "xii": {
                "value": 30
            }
        }}
    )

    # 按属性设置模型参数
    # 设置参数为时序值
    # cstr_3.params.operation.q_air.is_sequence = True
    # cstr_3.params.operation.q_air.sequence = [
    #     [
    #         1000,
    #         2000,
    #         3000,
    #         4000,
    #         5000,
    #         6000
    #     ],
    # ]
    cstr_1.params.physical.volume.value = 200.
    cstr_2.params.physical.volume.value = 300.
    cstr_3.params.physical.volume.value = 700.
    cstr_3.params.operation.q_pump.value = 2000.  # 抽水量的设置
    cstr_3.params.operation.q_air.value = 5000.
    seclar.params.operation.ras_mode.value = 1

    # 3.载入模型到process
    modules = [inf_module, cstr_1, cstr_2, cstr_3, seclar]
    process.load_modules(modules)

    # 4.构造模型间的连接关系
    # 进水与1#相连
    process.append_connect(inf_module, inf_module.ports.out_port, cstr_1, cstr_1.ports.in_port)
    # 1#出水与2#进水相连
    process.append_connect(cstr_1, cstr_1.ports.out_port, cstr_2, cstr_2.ports.in_port)
    # 2#出水与3#进水相连
    process.append_connect(cstr_2, cstr_2.ports.out_port, cstr_3, cstr_3.ports.in_port)
    # 3#向2#抽水
    process.append_connect(cstr_3, cstr_3.ports.pump_port, cstr_2, cstr_2.ports.converge_port)
    # 3#出水与seclar进水相连
    process.append_connect(cstr_3, cstr_3.ports.out_port, seclar, seclar.ports.in_port)
    # seclar向1#回流
    process.append_connect(seclar, seclar.ports.ras_port, cstr_1, cstr_1.ports.converge_port)

    # 5.求解方程
    start = 0
    terminal = 1
    interval = 0.01
    ar = Arithmetic(process=process, start=start, terminal=terminal, interval=interval)

    ar.solve(before_ode_fun=before_ode_fun, after_ode_fun=after_ode_fun)
    base_dir = os.path.dirname(os.path.abspath(__file__))
    results_path = os.path.join(base_dir, 'results')
    if not os.path.exists(results_path):
        if not os.path.isdir(results_path):
            os.mkdir(results_path)
    np.savetxt(os.path.join(results_path, 'results.txt'), ar.result_test, fmt="%.5f", delimiter=",")

    # 5.绘图
    # 一个反应池一个图
    drawing(start, terminal, interval, "inf")
    drawing(start, terminal, interval, "1#")
    drawing(start, terminal, interval, "2#")
    drawing(start, terminal, interval, "3#")
    drawing(start, terminal, interval, "seclar")
