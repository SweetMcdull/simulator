# -*- coding: utf-8 -*-
# @Time : 2020/4/20 18:52
# @Author : daijie
# @Site : 
# @File : flow_in_data
# @Software: PyCharm 

import numpy as np


# 外部输入的流量定义
num = 24
arr_flow = np.zeros(num)
arr_flow[0] = 3000
arr_flow[1] = 3000
arr_flow[2] = 3000
arr_flow[3] = 3000
arr_flow[4] = 3000
arr_flow[5] = 8000
arr_flow[6] = 8000
arr_flow[7] = 8000
arr_flow[8] = 3000
arr_flow[9] = 3000
arr_flow[10] = 3000
arr_flow[11] = 3000
arr_flow[12] = 3000
arr_flow[13] = 3000
arr_flow[14] = 3000
arr_flow[15] = 3000
arr_flow[16] = 3000
arr_flow[17] = 3000
arr_flow[18] = 3000
arr_flow[19] = 3000
arr_flow[20] = 3000
arr_flow[21] = 3000
arr_flow[22] = 3000
arr_flow[23] = 3000



def get_flow(t: float, end: float) -> float:
    """获取当前流量
    @param t:
    @param end:
    @return: float 流量
    """

    t1 = t % 1

    index = int(num * t1)

    return arr_flow[index]