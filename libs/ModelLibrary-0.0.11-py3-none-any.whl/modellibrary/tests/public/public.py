from modellibrary.src.main.python.core.algorithm.process import Process


def before_ode_fun(pro: Process, t: float, end: float):
    """在计算之前，可以修改模型变量
    @param pro: 流程对象
    @param t:当前时刻
    @param end:结束时间
    @return: 无
    """

    module = pro.get_module("inf")
    assert (module is not None)

    # module.variables.flow_out.value = get_flow(t, end)


def after_ode_fun(pro: Process, t: float, end: float):
    """查看某一变量的某一时刻的值,显示进度、修改变量值"""

    # module = pro.get_module("1#")
    # assert (module is not None)
    # flow_in = module.variables.flow_in.value
    # flow_out = module.variables.flow_out.value
    # so = module.variables.so.value
    # print(f"{module.id}：t={t}, flow_in={flow_in}, flow_out={flow_out}，so={so:.3f}")
