import json
from collections import OrderedDict

from modellibrary.src.main.python.core.algorithm.arithmetic import Arithmetic
from modellibrary.src.main.python.core.algorithm.process import Process
from modellibrary.src.main.python.core.models.factory.modelfactory import ModelFactory


class ProcessPlus:
    """流程+算法集成"""

    def __init__(self, config_path=None, data=None):
        assert config_path or data, 'config_path or data must be set'
        if not data:
            # 加载配置
            with open(config_path, encoding='utf-8') as f:
                data = json.load(f)

        # 2. 解析数据、构造模型、设置参数
        modules_dict = OrderedDict()  # 有序字典
        modules = {m['id']: m for m in data["modules"]}  # 模型列表转成字典

        # 保存结果的数组转成字典
        result_setting = {item['id']: item for item in data['result_setting']}

        for mid in data['sorted']:  # 根据顺序设置模型
            module_info = modules[mid]
            # 基础信息
            module_id = mid
            category = module_info['category']
            # 参数信息
            params_info = module_info['params']

            # 设置参数
            module = ModelFactory.create_model_by_name(category, module_id)
            module.set_params(
                params_info
            )

            # 设置要保存的变量
            if result_setting.get(module_id):
                save_var_names = result_setting[module_id]['names']
                module.set_save_var(save_var_names)

            # 有序插入
            modules_dict[module_id] = module

        # 3.加载模型
        edges = data['edges']
        process = Process()
        process.load_modules_by_config(modules_dict, edges)

        # 构造算法对象
        sys_config = data['sys_config']
        terminal = sys_config['simulate_config']['terminal']
        interval = sys_config['simulate_config']['interval']
        integrator_config = sys_config.get('integrator_config', {})
        integrator_name = integrator_config.get('name', 'vode')
        integrator_params = integrator_config.get('params', {})
        arithmetic = Arithmetic(process=process, terminal=terminal, interval=interval,
                                solver=integrator_name,
                                **integrator_params)

        self.process = process
        self.arithmetic = arithmetic
