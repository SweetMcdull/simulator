# -*- coding: utf-8 -*-
from enum import Enum

import numpy as np

from .constants import *
from ..models.asm2d.params.constants import ModuleType
from ..tools.logger import Logger

log = Logger(__name__)


class Process:
    def __init__(self):
        """构造函数"""

        # 模型
        self.modules = []
        self.use_init_value = False

        self.status = StatusCode.PROGRESS

    def load_modules(self, modules):
        """加载模型"""
        # TODO 拓扑排序
        self.modules = modules

    def load_modules_by_config(self, modules, edges):
        """以配置文件形式加载模型"""
        for mid, module in modules.items():
            self.modules.append(module)

        # 配置连接
        for edge in edges:
            source_module_id = edge['source_module']
            source_port_id = edge['source_port']
            source_module = modules[source_module_id]
            source_port = source_module.get_port_by_id(source_port_id)

            target_module_id = edge['target_module']
            target_port_id = edge['target_port']
            target_module = modules[target_module_id]
            target_port = target_module.get_port_by_id(target_port_id)
            self.append_connect(source_module, source_port, target_module, target_port)

    def get_module(self, module_id):
        for m in self.modules:
            if m.id == module_id:
                return m

    def get_inf_module(self):
        return self.modules[0]

    def append_connect(self, source_module, source_port, target_module, target_port):
        """
        仅仅做模型端口连接及连接校验
        """
        # TODO 连接校验
        source_port.next = target_port
        # log.logger.debug(f"{source_module.id}的{source_port.id}下一个端口为{source_port.next.module.id}的{source_port.next.id}")

    def build_process(self, t, y):
        """流程构建"""
        var_all_num = 0
        for module in self.modules:
            if module.category != ModuleType.INFLOW_MODULE:
                var_all_num += module.var_num
        dy = np.zeros(var_all_num)

        # 根据微分y设置每个反应池的组分变量值（变步长变量值随动变化）,并主动向下一个端口推送更新数据
        y_index = 0
        for index, module in enumerate(self.modules):
            if module.category == ModuleType.INFLOW_MODULE:
                last_port = module.ports.out_port
                next_port = last_port.next
                next_port.transfer_data(last_port)
                continue
            var_num = module.var_num
            module_y = y[y_index:y_index + var_num]
            module.update_denseness(module_y)
            module.push_to_next()
            y_index += var_num

        y_index_1 = 0
        for index, module in enumerate(self.modules[1:]):
            # 混合水流
            q_remixed, y_remixed = module.update_flow(self)
            module_dy = module.ode_fun(q_remixed, y_remixed, np.array(module.denseness), self)
            var_num = module.var_num
            dy[y_index_1:y_index_1 + var_num] = module_dy
            y_index_1 += var_num
        return dy


class StatusCode(str, Enum):
    STOP = 'STOP',
    PAUSE = 'PAUSE'
    RESUME = 'RESUME'
    PROGRESS = 'PROGRESS'
