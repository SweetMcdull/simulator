import time

from modellibrary.src.main.python.core.tools.logger import Logger

log = Logger(__name__)


def timer(func):
    def wrapper(*args, **kwargs):
        start = time.time()
        func(*args, **kwargs)
        end = time.time()
        print(f"{func.__name__}花费时间：{end - start}秒")

    return wrapper
