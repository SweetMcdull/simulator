# -*- coding: utf-8 -*-
from modellibrary.src.main.python.core.common.base import BaseModule, BaseAttrs
from modellibrary.src.main.python.core.models.asm2d.params.constants import ModuleType
from modellibrary.src.main.python.core.models.asm2d.models.inflow.paramset import ParamSet
from modellibrary.src.main.python.core.models.asm2d.models.inflow.portset import PortSet
from modellibrary.src.main.python.core.models.asm2d.models.inflow.variableset import VariableSet
from modellibrary.src.main.python.core.models.asm2d.public.publicfun import PublicFun


class InflowModule(BaseModule):
    """进水模块"""

    def __init__(self, id: str):
        """
        进水模块构造函数
        :param id:进水模块唯一编号，字符串类型
        """
        # 基础属性
        self.__attrs = BaseAttrs(id, ModuleType.INFLOW_MODULE)
        # 参数集合
        self.params = ParamSet()
        # 变量集合
        self.variables = VariableSet(self)
        # 端口集合
        self.ports = PortSet(self)

    @property
    def id(self):
        return self.__attrs.id

    @property
    def category(self):
        return self.__attrs.category

    @property
    def denseness(self):
        return self.variables.denseness

    def set_params(self, data: dict):
        """设置参数
        {
            'inflow': {
                'flow': {
                    'value': 1000,
                    'is_save': False
                }
            },
        }
        """
        for p_name, vars_data in data.items():  # 解析每一类参数
            param_obj = getattr(self.params, p_name)
            for v_name, var_data in vars_data.items():  # 解析每一个参数
                var_obj = getattr(param_obj, v_name)
                for attr_name, value in var_data.items():  # 设置每一个属性
                    setattr(var_obj, attr_name, value)

    def add_to_result(self, index, y):
        self.variables.flow_out.append_result(index, self.variables.flow_out.value)
        so, sf, sa, snh, sno, spo, si, salk, snn, xi, xs, xh, xpao, xpp, xpha, xaut, xmeoh, xmep, xii = y

        cod, bod, tss, tn, tp = PublicFun.asm2d_get_compos(self.denseness, self.params.stoichi)

        self.variables.so.append_result(index, so)
        self.variables.sf.append_result(index, sf)
        self.variables.sa.append_result(index, sa)
        self.variables.snh.append_result(index, snh)
        self.variables.sno.append_result(index, sno)
        self.variables.spo.append_result(index, spo)
        self.variables.si.append_result(index, si)
        self.variables.salk.append_result(index, salk)
        self.variables.snn.append_result(index, snn)
        self.variables.xi.append_result(index, xi)
        self.variables.xs.append_result(index, xs)
        self.variables.xh.append_result(index, xh)
        self.variables.xpao.append_result(index, xpao)
        self.variables.xpp.append_result(index, xpp)
        self.variables.xpha.append_result(index, xpha)
        self.variables.xaut.append_result(index, xaut)
        self.variables.xmeoh.append_result(index, xmeoh)
        self.variables.xmep.append_result(index, xmep)
        self.variables.xii.append_result(index, xii)

        self.variables.cod.append_result(index, cod)
        self.variables.bod.append_result(index, bod)
        self.variables.tss.append_result(index, tss)
        self.variables.tn.append_result(index, tn)
        self.variables.tp.append_result(index, tp)

    def init(self, times: int, process):
        """
        :param times:仿真计算次数，int类型
        """

        # ##------------------------------------------------------------------
        # 流量
        self.variables.flow_out.value = self.params.inflow.flow.value
        self.variables.flow_out.init_result(times)

        # ##-----------------------------------------------------------------
        # 进水条件赋值
        so = self.params.inflow.so.value
        sf = self.params.inflow.sf.value
        sa = self.params.inflow.sa.value
        snh = self.params.inflow.snh.value
        sno = self.params.inflow.sno.value
        spo = self.params.inflow.spo.value
        si = self.params.inflow.si.value
        salk = self.params.inflow.salk.value
        snn = self.params.inflow.snn.value
        xi = self.params.inflow.xi.value
        xs = self.params.inflow.xs.value
        xh = self.params.inflow.xh.value
        xpao = self.params.inflow.xpao.value
        xpp = self.params.inflow.xpp.value
        xpha = self.params.inflow.xpha.value
        xaut = self.params.inflow.xaut.value
        xmep = self.params.inflow.xmep.value
        xmeoh = self.params.inflow.xmeoh.value
        xii = self.params.inflow.xii.value
        y = [so, sf, sa, snh, sno, spo, si, salk, snn, xi, xs, xh, xpao, xpp, xpha, xaut, xmeoh, xmep, xii]

        self.variables.so.value = so
        self.variables.sf.value = sf
        self.variables.sa.value = sa
        self.variables.snh.value = snh
        self.variables.sno.value = sno
        self.variables.spo.value = spo
        self.variables.si.value = si
        self.variables.salk.value = salk
        self.variables.snn.value = snn
        self.variables.xi.value = xi
        self.variables.xs.value = xs
        self.variables.xh.value = xh
        self.variables.xpao.value = xpao
        self.variables.xpp.value = xpp
        self.variables.xpha.value = xpha
        self.variables.xaut.value = xaut
        self.variables.xmep.value = xmep
        self.variables.xmeoh.value = xmeoh
        self.variables.xii.value = xii

        cod, bod, tss, tn, tp = PublicFun.asm2d_get_compos(y, self.params.stoichi)
        self.variables.cod.value = cod
        self.variables.bod.value = bod
        self.variables.tss.value = tss
        self.variables.tn.value = tn
        self.variables.tp.value = tp

        # 出水
        self.variables.so.init_result(times)
        self.variables.sf.init_result(times)
        self.variables.sa.init_result(times)
        self.variables.snh.init_result(times)
        self.variables.sno.init_result(times)
        self.variables.spo.init_result(times)
        self.variables.si.init_result(times)
        self.variables.salk.init_result(times)
        self.variables.snn.init_result(times)
        self.variables.xi.init_result(times)
        self.variables.xs.init_result(times)
        self.variables.xh.init_result(times)
        self.variables.xpao.init_result(times)
        self.variables.xpp.init_result(times)
        self.variables.xpha.init_result(times)
        self.variables.xaut.init_result(times)
        self.variables.xmep.init_result(times)
        self.variables.xmeoh.init_result(times)
        self.variables.xii.init_result(times)

        self.variables.cod.init_result(times)
        self.variables.bod.init_result(times)
        self.variables.tss.init_result(times)
        self.variables.tn.init_result(times)
        self.variables.tp.init_result(times)

    def get_port_by_id(self, pid):
        """通过port id 获取port"""
        return self.ports.set.get(pid)

    def save_result(self):
        result = {}
        for var_name, var_object in self.variables.set.items():
            if var_object.is_save:
                result[var_name] = list(var_object.results)
        return result

    def get_current_result(self):
        return {var_name: round(var_object.value, 3) for var_name, var_object in
                self.variables.set.items()}

    def set_save_var(self, names: list):
        """设置需要保存结果的变量"""
        for name in names:
            var_object = self.variables.set.get(name)
            if var_object:
                var_object.is_save = True

    def update_param_by_t(self, t: float):
        """根据时间t更新为时间序列的参数的参数值"""
        self.params.update_by_t(t)

        self.variables.flow_out.value = self.params.inflow.flow.value

        self.variables.so.value = self.params.inflow.so.value
        self.variables.sf.value = self.params.inflow.sf.value
        self.variables.sa.value = self.params.inflow.sa.value
        self.variables.snh.value = self.params.inflow.snh.value
        self.variables.sno.value = self.params.inflow.sno.value
        self.variables.spo.value = self.params.inflow.spo.value
        self.variables.si.value = self.params.inflow.si.value
        self.variables.salk.value = self.params.inflow.salk.value
        self.variables.snn.value = self.params.inflow.snn.value
        self.variables.xi.value = self.params.inflow.xi.value
        self.variables.xs.value = self.params.inflow.xs.value
        self.variables.xh.value = self.params.inflow.xh.value
        self.variables.xpao.value = self.params.inflow.xpao.value
        self.variables.xpp.value = self.params.inflow.xpp.value
        self.variables.xpha.value = self.params.inflow.xpha.value
        self.variables.xaut.value = self.params.inflow.xaut.value
        self.variables.xmeoh.value = self.params.inflow.xmeoh.value
        self.variables.xmep.value = self.params.inflow.xmep.value
        self.variables.xii.value = self.params.inflow.xii.value

        cod, bod, tss, tn, tp = PublicFun.asm2d_get_compos(self.denseness, self.params.stoichi)
        self.variables.cod.value = cod
        self.variables.bod.value = bod
        self.variables.tss.value = tss
        self.variables.tn.value = tn
        self.variables.tp.value = tp
