# -*- coding: utf-8 -*-
from modellibrary.src.main.python.core.models.asm2d.params.constants import VariableTypeName
from ..constants import InflowDefaultValue
from modellibrary.src.main.python.core.common.variable import Variable


class InflowParams:
    """进水参数"""

    def __init__(self):
        self.flow = Variable(VariableTypeName.FLOW, default=InflowDefaultValue.FLOW)

        self.so = Variable(VariableTypeName.SO, default=InflowDefaultValue.SO)
        self.sf = Variable(VariableTypeName.SF, default=InflowDefaultValue.SF)
        self.sa = Variable(VariableTypeName.SA, default=InflowDefaultValue.SA)
        self.snh = Variable(VariableTypeName.SNH, default=InflowDefaultValue.SNH)
        self.sno = Variable(VariableTypeName.SNO, default=InflowDefaultValue.SNO)
        self.spo = Variable(VariableTypeName.SPO, default=InflowDefaultValue.SPO)
        self.si = Variable(VariableTypeName.SI, default=InflowDefaultValue.SI)
        self.salk = Variable(VariableTypeName.SALK, default=InflowDefaultValue.SALK)
        self.snn = Variable(VariableTypeName.SNN, default=InflowDefaultValue.SNN)
        self.xi = Variable(VariableTypeName.XI, default=InflowDefaultValue.XI)
        self.xs = Variable(VariableTypeName.XS, default=InflowDefaultValue.XS)
        self.xh = Variable(VariableTypeName.XH, default=InflowDefaultValue.XH)
        self.xpao = Variable(VariableTypeName.XPAO, default=InflowDefaultValue.XPAO)
        self.xpp = Variable(VariableTypeName.XPP, default=InflowDefaultValue.XPP)
        self.xpha = Variable(VariableTypeName.XPHA, default=InflowDefaultValue.XPHA)
        self.xaut = Variable(VariableTypeName.XAUT, default=InflowDefaultValue.XAUT)
        self.xmeoh = Variable(VariableTypeName.XMEOH, default=InflowDefaultValue.XMEOH)
        self.xmep = Variable(VariableTypeName.XMEP, default=InflowDefaultValue.XMEP)
        self.xii = Variable(VariableTypeName.XII, default=InflowDefaultValue.XII)

    def update_by_t(self, t: float):
        self.flow.update_value_by_t(t)

        self.so.update_value_by_t(t)
        self.sf.update_value_by_t(t)
        self.sa.update_value_by_t(t)
        self.snh.update_value_by_t(t)
        self.sno.update_value_by_t(t)
        self.spo.update_value_by_t(t)
        self.si.update_value_by_t(t)
        self.salk.update_value_by_t(t)
        self.snn.update_value_by_t(t)
        self.xi.update_value_by_t(t)
        self.xs.update_value_by_t(t)
        self.xh.update_value_by_t(t)
        self.xpao.update_value_by_t(t)
        self.xpp.update_value_by_t(t)
        self.xpha.update_value_by_t(t)
        self.xaut.update_value_by_t(t)
        self.xmeoh.update_value_by_t(t)
        self.xmep.update_value_by_t(t)
        self.xii.update_value_by_t(t)
