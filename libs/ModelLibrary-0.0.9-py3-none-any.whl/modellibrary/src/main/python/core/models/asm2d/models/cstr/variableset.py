# -*- coding: utf-8 -*-
from modellibrary.src.main.python.core.models.asm2d.params.constants import VariableTypeName
from modellibrary.src.main.python.core.common.variable import Variable


class VariableSet:
    """变量集合"""

    def __init__(self, module):
        self.__module = module  # 所属模型

        self.flow_in = Variable(VariableTypeName.FLOW)
        self.flow_out = Variable(VariableTypeName.FLOW)
        self.flow_pump = Variable(VariableTypeName.FLOW)
        self.flow_converge = Variable(VariableTypeName.FLOW)

        # 模块(出水)组分
        self.so = Variable(VariableTypeName.SO)
        self.sf = Variable(VariableTypeName.SF)
        self.sa = Variable(VariableTypeName.SA)
        self.snh = Variable(VariableTypeName.SNH)
        self.sno = Variable(VariableTypeName.SNO)
        self.spo = Variable(VariableTypeName.SPO)  # 磷酸盐
        self.si = Variable(VariableTypeName.SI)
        self.salk = Variable(VariableTypeName.SALK)  # 碱度
        self.snn = Variable(VariableTypeName.SNN)
        self.xi = Variable(VariableTypeName.XI)
        self.xs = Variable(VariableTypeName.XS)
        self.xh = Variable(VariableTypeName.XH)
        self.xpao = Variable(VariableTypeName.XPAO)
        self.xpp = Variable(VariableTypeName.XPP)
        self.xpha = Variable(VariableTypeName.XPHA)
        self.xaut = Variable(VariableTypeName.XAUT)
        self.xmeoh = Variable(VariableTypeName.XMEOH)  # 氢氧化铁
        self.xmep = Variable(VariableTypeName.XMEP)  # 磷酸铁
        self.xii = Variable(VariableTypeName.XII)

        # 进水组分
        self.so_in = Variable(VariableTypeName.SO)
        self.sf_in = Variable(VariableTypeName.SF)
        self.sa_in = Variable(VariableTypeName.SA)
        self.snh_in = Variable(VariableTypeName.SNH)
        self.sno_in = Variable(VariableTypeName.SNO)
        self.spo_in = Variable(VariableTypeName.SPO)
        self.si_in = Variable(VariableTypeName.SI)
        self.salk_in = Variable(VariableTypeName.SALK)
        self.snn_in = Variable(VariableTypeName.SNN)
        self.xi_in = Variable(VariableTypeName.XI)
        self.xs_in = Variable(VariableTypeName.XS)
        self.xh_in = Variable(VariableTypeName.XH)
        self.xpao_in = Variable(VariableTypeName.XPAO)
        self.xpp_in = Variable(VariableTypeName.XPP)
        self.xpha_in = Variable(VariableTypeName.XPHA)
        self.xaut_in = Variable(VariableTypeName.XAUT)
        self.xmeoh_in = Variable(VariableTypeName.XMEOH)
        self.xmep_in = Variable(VariableTypeName.XMEP)
        self.xii_in = Variable(VariableTypeName.XII)

        # 汇流组分
        self.so_converge = Variable(VariableTypeName.SO)
        self.sf_converge = Variable(VariableTypeName.SF)
        self.sa_converge = Variable(VariableTypeName.SA)
        self.snh_converge = Variable(VariableTypeName.SNH)
        self.sno_converge = Variable(VariableTypeName.SNO)
        self.spo_converge = Variable(VariableTypeName.SPO)
        self.si_converge = Variable(VariableTypeName.SI)
        self.salk_converge = Variable(VariableTypeName.SALK)
        self.snn_converge = Variable(VariableTypeName.SNN)
        self.xi_converge = Variable(VariableTypeName.XI)
        self.xs_converge = Variable(VariableTypeName.XS)
        self.xh_converge = Variable(VariableTypeName.XH)
        self.xpao_converge = Variable(VariableTypeName.XPAO)
        self.xpp_converge = Variable(VariableTypeName.XPP)
        self.xpha_converge = Variable(VariableTypeName.XPHA)
        self.xaut_converge = Variable(VariableTypeName.XAUT)
        self.xmeoh_converge = Variable(VariableTypeName.XMEOH)
        self.xmep_converge = Variable(VariableTypeName.XMEP)
        self.xii_converge = Variable(VariableTypeName.XII)

        # 复合指标
        self.cod = Variable(VariableTypeName.COD)
        self.bod = Variable(VariableTypeName.BOD)
        self.tss = Variable(VariableTypeName.TSS)
        self.tn = Variable(VariableTypeName.TN)
        self.tp = Variable(VariableTypeName.TP)

        # TODO 以下以后备用
        # 流量集合
        self.flow_list = [self.flow_in, self.flow_out, self.flow_pump, self.flow_converge]

        self.set = {
            'flow_in': self.flow_in,
            'flow_out': self.flow_out,
            'flow_pump': self.flow_pump,
            'flow_converge': self.flow_converge,
            'so': self.so,
            'sf': self.sf,
            'sa': self.sa,
            'snh': self.snh,
            'sno': self.sno,
            'spo': self.spo,
            'si': self.si,
            'salk': self.salk,
            'snn': self.snn,
            'xi': self.xi,
            'xs': self.xs,
            'xh': self.xh,
            'xpao': self.xpao,
            'xpp': self.xpp,
            'xpha': self.xpha,
            'xaut': self.xaut,
            'xmeoh': self.xmeoh,
            'xmep': self.xmep,
            'xii': self.xii,
            'cod': self.cod,
            'bod': self.bod,
            'tss': self.tss,
            'tn': self.tn,
            'tp': self.tp,
            'so_in': self.so_in,
            'sf_in': self.sf_in,
            'sa_in': self.sa_in,
            'snh_in': self.snh_in,
            'sno_in': self.sno_in,
            'spo_in': self.spo_in,
            'si_in': self.si_in,
            'salk_in': self.salk_in,
            'snn_in': self.snn_in,
            'xi_in': self.xi_in,
            'xs_in': self.xs_in,
            'xh_in': self.xh_in,
            'xpao_in': self.xpao_in,
            'xpp_in': self.xpp_in,
            'xpha_in': self.xpha_in,
            'xaut_in': self.xaut_in,
            'xmeoh_in': self.xmeoh_in,
            'xmep_in': self.xmep_in,
            'xii_in': self.xii_in,
            'so_converge': self.so_converge,
            'sf_converge': self.sf_converge,
            'sa_converge': self.sa_converge,
            'snh_converge': self.snh_converge,
            'sno_converge': self.sno_converge,
            'spo_converge': self.spo_converge,
            'si_converge': self.si_converge,
            'salk_converge': self.salk_converge,
            'snn_converge': self.snn_converge,
            'xi_converge': self.xi_converge,
            'xs_converge': self.xs_converge,
            'xh_converge': self.xh_converge,
            'xpao_converge': self.xpao_converge,
            'xpp_converge': self.xpp_converge,
            'xpha_converge': self.xpha_converge,
            'xaut_converge': self.xaut_converge,
            'xmeoh_converge': self.xmeoh_converge,
            'xmep_converge': self.xmep_converge,
            'xii_converge': self.xii_converge,
        }

    @property
    def denseness_in(self):
        """进水组分浓度"""
        return [self.so_in.value,
                self.sf_in.value,
                self.sa_in.value,
                self.snh_in.value,
                self.sno_in.value,
                self.spo_in.value,
                self.si_in.value,
                self.salk_in.value,
                self.snn_in.value,
                self.xi_in.value,
                self.xs_in.value,
                self.xh_in.value,
                self.xpao_in.value,
                self.xpp_in.value,
                self.xpha_in.value,
                self.xaut_in.value,
                self.xmeoh_in.value,
                self.xmep_in.value,
                self.xii_in.value]

    @property
    def denseness(self):
        """模型（出水）组分浓度列表"""
        return [self.so.value,
                self.sf.value,
                self.sa.value,
                self.snh.value,
                self.sno.value,
                self.spo.value,
                self.si.value,
                self.salk.value,
                self.snn.value,
                self.xi.value,
                self.xs.value,
                self.xh.value,
                self.xpao.value,
                self.xpp.value,
                self.xpha.value,
                self.xaut.value,
                self.xmeoh.value,
                self.xmep.value,
                self.xii.value]

    @property
    def denseness_pump(self):
        """抽水浓度列表"""
        return [self.so.value,
                self.sf.value,
                self.sa.value,
                self.snh.value,
                self.sno.value,
                self.spo.value,
                self.si.value,
                self.salk.value,
                self.snn.value,
                self.xi.value,
                self.xs.value,
                self.xh.value,
                self.xpao.value,
                self.xpp.value,
                self.xpha.value,
                self.xaut.value,
                self.xmeoh.value,
                self.xmep.value,
                self.xii.value]

    # 汇流组分浓度
    @property
    def denseness_converge(self):
        return [self.so_converge.value,
                self.sf_converge.value,
                self.sa_converge.value,
                self.snh_converge.value,
                self.sno_converge.value,
                self.spo_converge.value,
                self.si_converge.value,
                self.salk_converge.value,
                self.snn_converge.value,
                self.xi_converge.value,
                self.xs_converge.value,
                self.xh_converge.value,
                self.xpao_converge.value,
                self.xpp_converge.value,
                self.xpha_converge.value,
                self.xaut_converge.value,
                self.xmeoh_converge.value,
                self.xmep_converge.value,
                self.xii_converge.value]

    def get_port_in_vars(self):
        """进水变量集合"""
        return [self.flow_in,
                self.so_in,
                self.sf_in,
                self.sa_in,
                self.snh_in,
                self.sno_in,
                self.spo_in,
                self.si_in,
                self.salk_in,
                self.snn_in,
                self.xi_in,
                self.xs_in,
                self.xh_in,
                self.xpao_in,
                self.xpp_in,
                self.xpha_in,
                self.xaut_in,
                self.xmeoh_in,
                self.xmep_in,
                self.xii_in]

    def get_port_out_vars(self):
        """出水变量集合"""
        return [self.flow_out,
                self.so,
                self.sf,
                self.sa,
                self.snh,
                self.sno,
                self.spo,
                self.si,
                self.salk,
                self.snn,
                self.xi,
                self.xs,
                self.xh,
                self.xpao,
                self.xpp,
                self.xpha,
                self.xaut,
                self.xmeoh,
                self.xmep,
                self.xii]

    def get_port_pump_vars(self):
        """抽水变量集合"""
        return [self.flow_pump,
                self.so,
                self.sf,
                self.sa,
                self.snh,
                self.sno,
                self.spo,
                self.si,
                self.salk,
                self.snn,
                self.xi,
                self.xs,
                self.xh,
                self.xpao,
                self.xpp,
                self.xpha,
                self.xaut,
                self.xmeoh,
                self.xmep,
                self.xii]

    def get_port_converge_vars(self):
        """汇流变量集合"""
        return [self.flow_converge,
                self.so_converge,
                self.sf_converge,
                self.sa_converge,
                self.snh_converge,
                self.sno_converge,
                self.spo_converge,
                self.si_converge,
                self.salk_converge,
                self.snn_converge,
                self.xi_converge,
                self.xs_converge,
                self.xh_converge,
                self.xpao_converge,
                self.xpp_converge,
                self.xpha_converge,
                self.xaut_converge,
                self.xmeoh_converge,
                self.xmep_converge,
                self.xii_converge]
