# -*- coding: utf-8 -*-
from modellibrary.src.main.python.core.models.asm2d.params.constants import VariableTypeName
from modellibrary.src.main.python.core.common.variable import Variable


class VariableSet:
    """变量集合"""

    def __init__(self, module):
        self.__module = module  # 所属模型

        # 模块流量
        self.flow_out = Variable(VariableTypeName.FLOW)

        # 模块(出水)组分
        self.so = Variable(VariableTypeName.SO)
        self.sf = Variable(VariableTypeName.SF)
        self.sa = Variable(VariableTypeName.SA)
        self.snh = Variable(VariableTypeName.SNH)
        self.sno = Variable(VariableTypeName.SNO)
        self.spo = Variable(VariableTypeName.SPO)  # 磷酸盐
        self.si = Variable(VariableTypeName.SI)
        self.salk = Variable(VariableTypeName.SALK)  # 碱度
        self.snn = Variable(VariableTypeName.SNN)
        self.xi = Variable(VariableTypeName.XI)
        self.xs = Variable(VariableTypeName.XS)
        self.xh = Variable(VariableTypeName.XH)
        self.xpao = Variable(VariableTypeName.XPAO)
        self.xpp = Variable(VariableTypeName.XPP)
        self.xpha = Variable(VariableTypeName.XPHA)
        self.xaut = Variable(VariableTypeName.XAUT)
        self.xmeoh = Variable(VariableTypeName.XMEOH)  # 氢氧化铁
        self.xmep = Variable(VariableTypeName.XMEP)  # 磷酸铁
        self.xii = Variable(VariableTypeName.XII)

        # 复合指标
        self.cod = Variable(VariableTypeName.COD)  # 模型化学需氧量
        self.bod = Variable(VariableTypeName.BOD)
        self.tss = Variable(VariableTypeName.TSS)
        self.tn = Variable(VariableTypeName.TN)
        self.tp = Variable(VariableTypeName.TP)

        self.set = {
            'flow_out': self.flow_out,
            'so': self.so,
            'sf': self.sf,
            'sa': self.sa,
            'snh': self.snh,
            'sno': self.sno,
            'spo': self.spo,
            'si': self.si,
            'salk': self.salk,
            'snn': self.snn,
            'xi': self.xi,
            'xs': self.xs,
            'xh': self.xh,
            'xpao': self.xpao,
            'xpp': self.xpp,
            'xpha': self.xpha,
            'xaut': self.xaut,
            'xmeoh': self.xmeoh,
            'xmep': self.xmep,
            'xii': self.xii,
            'xii': self.xii,
            'cod': self.cod,
            'bod': self.bod,
            'tss': self.tss,
            'tn': self.tn,
            'tp': self.tp,
        }

        # TODO 以下以后备用
        # 流量集合
        self.flow_list = [self.flow_out, ]

    @property
    def denseness(self):
        """模型（出水）组分浓度列表"""
        return [self.so.value,
                self.sf.value,
                self.sa.value,
                self.snh.value,
                self.sno.value,
                self.spo.value,
                self.si.value,
                self.salk.value,
                self.snn.value,
                self.xi.value,
                self.xs.value,
                self.xh.value,
                self.xpao.value,
                self.xpp.value,
                self.xpha.value,
                self.xaut.value,
                self.xmeoh.value,
                self.xmep.value,
                self.xii.value]

    def get_port_out_vars(self):
        """出水变量集合"""
        return [self.flow_out,
                self.so,
                self.sf,
                self.sa,
                self.snh,
                self.sno,
                self.spo,
                self.si,
                self.salk,
                self.snn,
                self.xi,
                self.xs,
                self.xh,
                self.xpao,
                self.xpp,
                self.xpha,
                self.xaut,
                self.xmeoh,
                self.xmep,
                self.xii]
