# -*- coding: utf-8 -*-
from ..constants import PhysicalTypeName, PhysicalDefaultValue
from modellibrary.src.main.python.core.common.variable import Variable


class PhysicalParams:
    """物理参数"""

    def __init__(self):
        self.volume = Variable(PhysicalTypeName.VOLUME, default=PhysicalDefaultValue.VOLUME)

    def update_by_t(self, t: float):
        self.volume.update_value_by_t(t)
