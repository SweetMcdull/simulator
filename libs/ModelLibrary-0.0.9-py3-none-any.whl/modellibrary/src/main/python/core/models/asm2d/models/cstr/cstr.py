# -*- coding: utf-8 -*-
import numpy as np

from modellibrary.src.main.python.core.common.base import BaseModule, BaseAttrs
from .constants import COMPONENT_NUM, PumpOperationMode
from modellibrary.src.main.python.core.models.asm2d.params.constants import ModuleType
from modellibrary.src.main.python.core.models.asm2d.models.cstr.paramset import ParamSet
from modellibrary.src.main.python.core.models.asm2d.models.cstr.portset import PortSet
from modellibrary.src.main.python.core.models.asm2d.models.cstr.variableset import VariableSet
from modellibrary.src.main.python.core.models.asm2d.public.publicfun import PublicFun, WaterProcessor
from modellibrary.src.main.python.core.tools.logger import Logger

log = Logger(__name__)


class CSTRModule(BaseModule):
    """CSTR模块"""

    def __init__(self, id: str):
        """
        CSTR模块构造函数
        :param id:进水模块唯一编号，字符串类型
        """
        # 基础属性
        self.__attrs = BaseAttrs(id, ModuleType.REACTION_MODULE)
        # 参数集合
        self.params = ParamSet()
        # 变量集合
        self.variables = VariableSet(self)
        # 端口集合
        self.ports = PortSet(self)

    @property
    def id(self):
        return self.__attrs.id

    @property
    def category(self):
        return self.__attrs.category

    @property
    def var_num(self):
        return COMPONENT_NUM

    @property
    def denseness(self):
        return self.variables.denseness

    @property
    def denseness_in(self):
        return self.variables.denseness_in

    @property
    def denseness_converge(self):
        return self.variables.denseness_converge

    def valid(self):
        """校验"""
        if self.ports.pump_port.next:
            if self.params.operation.ras_mode == PumpOperationMode.BY_RATIO and self.params.operation.ras_ratio.value <= 0.:
                return False
            if self.params.operation.ras_mode == PumpOperationMode.BY_FLOW and self.params.operation.q_pump.value <= 0.:
                return False
        else:
            self.params.operation.ras_ratio.value = 0.
            self.params.operation.ras_ratio.is_sequence = False
            self.params.operation.q_pump.value = 0.
            self.params.operation.q_pump.is_sequence = False
        return True

    def set_params(self, data: dict):
        """设置参数
        {
            'inflow': {
                'flow': {
                    'value': 1000,
                    'is_save': False
                }
            },
        }
        """
        for p_name, vars_data in data.items():  # 解析每一类参数
            param_obj = getattr(self.params, p_name)
            for v_name, var_data in vars_data.items():  # 解析每一个参数
                var_obj = getattr(param_obj, v_name)
                for attr_name, value in var_data.items():  # 设置每一个属性
                    setattr(var_obj, attr_name, value)

    def update_denseness(self, y):
        """更新组分变量变量值，并向有下一个端口的进行变量传递"""
        # 更新组分变量
        so, sf, sa, snh, sno, spo, si, salk, snn, xi, xs, xh, xpao, xpp, xpha, xaut, xmeoh, xmep, xii = y
        self.variables.so.value = so
        self.variables.sf.value = sf
        self.variables.sa.value = sa
        self.variables.snh.value = snh
        self.variables.sno.value = sno
        self.variables.spo.value = spo
        self.variables.si.value = si
        self.variables.salk.value = salk
        self.variables.xmeoh.value = xmeoh
        self.variables.snn.value = snn
        self.variables.xi.value = xi
        self.variables.xs.value = xs
        self.variables.xh.value = xh
        self.variables.xpao.value = xpao
        self.variables.xpp.value = xpp
        self.variables.xpha.value = xpha
        self.variables.xaut.value = xaut
        self.variables.xmep.value = xmep
        self.variables.xmeoh.value = xmeoh
        self.variables.xii.value = xii
        # 更新复合指标
        cod, bod, tss, tn, tp = PublicFun.asm2d_get_compos(y, self.params.stoichi)
        self.variables.cod.value = cod
        self.variables.bod.value = bod
        self.variables.tss.value = tss
        self.variables.tn.value = tn
        self.variables.tp.value = tp

    def push_to_next(self):
        # 推送数据
        if self.ports.out_port.next:
            # log.logger.debug(f"{self.ports.out_port.id}向{self.ports.out_port.next.id}推送数据")
            self.ports.out_port.next.transfer_data(self.ports.out_port)

        if self.ports.pump_port.next:
            # log.logger.debug(f"{self.ports.pump_port.id}向{self.ports.pump_port.next.id}推送数据")
            self.ports.pump_port.next.transfer_data(self.ports.pump_port)

    def update_flow(self, process):
        """根据模型连接关系进行水流混合
        返回混合后的水流流量+混合后的组分浓度
        """
        inf_module = process.get_inf_module()
        qinf = inf_module.variables.flow_out.value

        flow_list = []
        denseness_list = []

        flow_list.append(self.variables.flow_in.value)  # 进水端口流量
        denseness_list.append(np.array(self.denseness_in))  # 进水组分
        flow_list.append(self.variables.flow_converge.value)  # 汇流端口流量
        denseness_list.append(np.array(self.denseness_converge))  # 汇流组分
        # 混合水流
        q_remixed, y_remixed = WaterProcessor.combiner(flow_list, denseness_list)

        # 更新出水、抽水
        ras_mode = self.params.operation.ras_mode.value
        if PumpOperationMode(ras_mode) == PumpOperationMode.BY_RATIO:  # 回流比
            ras_ratio = self.params.operation.ras_ratio.value
            q_pump = ras_ratio * qinf
        else:
            q_pump = self.params.operation.q_pump.value
        self.variables.flow_pump.value = q_pump
        q_out = q_remixed - q_pump  # 出水流量
        self.variables.flow_out.value = q_out

        # 推送数据
        if self.ports.out_port.next:
            # log.logger.debug(f"{self.ports.out_port.id}向{self.ports.out_port.next.id}推送数据")
            self.ports.out_port.next.module.variables.flow_in.value = self.variables.flow_out.value

        if self.ports.pump_port.next:
            module = self.ports.pump_port.next.module
            module.variables.flow_converge.value = self.variables.flow_pump.value
            # log.logger.debug(f"{self.ports.pump_port.id}向{self.ports.pump_port.next.id}推送数据")
        return q_remixed, y_remixed

    def add_to_result(self, index, y):
        """添加变量结果并将变量当前值更新"""
        so, sf, sa, snh, sno, spo, si, salk, snn, xi, xs, xh, xpao, xpp, xpha, xaut, xmeoh, xmep, xii = y

        cod, bod, tss, tn, tp = PublicFun.asm2d_get_compos(y, self.params.stoichi)

        self.variables.flow_in.append_result(index, self.variables.flow_in.value)
        self.variables.flow_out.append_result(index, self.variables.flow_out.value)
        self.variables.flow_pump.append_result(index, self.variables.flow_pump.value)
        self.variables.flow_converge.append_result(index, self.variables.flow_converge.value)

        self.variables.so.append_result(index, so)
        self.variables.sf.append_result(index, sf)
        self.variables.sa.append_result(index, sa)
        self.variables.snh.append_result(index, snh)
        self.variables.sno.append_result(index, sno)
        self.variables.spo.append_result(index, spo)
        self.variables.si.append_result(index, si)
        self.variables.salk.append_result(index, salk)
        self.variables.snn.append_result(index, snn)
        self.variables.xi.append_result(index, xi)
        self.variables.xs.append_result(index, xs)
        self.variables.xh.append_result(index, xh)
        self.variables.xpao.append_result(index, xpao)
        self.variables.xpp.append_result(index, xpp)
        self.variables.xpha.append_result(index, xpha)
        self.variables.xaut.append_result(index, xaut)
        self.variables.xmeoh.append_result(index, xmeoh)
        self.variables.xmep.append_result(index, xmep)
        self.variables.xii.append_result(index, xii)

        self.variables.cod.append_result(index, cod)
        self.variables.bod.append_result(index, bod)
        self.variables.tss.append_result(index, tss)
        self.variables.tn.append_result(index, tn)
        self.variables.tp.append_result(index, tp)

    def init(self, times: int, process):
        """
        :param times:仿真计算次数，int类型
        """
        inf_module = process.get_inf_module()
        qinf = inf_module.variables.flow_out.value

        # ##------------------------------------------------------------------
        # 流量
        ras_mode = self.params.operation.ras_mode.value
        if PumpOperationMode(ras_mode) == PumpOperationMode.BY_RATIO:  # 回流比
            ras_ratio = self.params.operation.ras_ratio.value
            q_pump = ras_ratio * qinf
        else:
            q_pump = self.params.operation.q_pump.value
        self.variables.flow_pump.value = q_pump

        self.variables.flow_in.init_result(times)
        self.variables.flow_out.init_result(times)
        self.variables.flow_pump.init_result(times)
        self.variables.flow_converge.init_result(times)

        # ##-----------------------------------------------------------------

        # 初始条件赋值
        so = self.params.initial.so.value
        sf = self.params.initial.sf.value
        sa = self.params.initial.sa.value
        snh = self.params.initial.snh.value
        sno = self.params.initial.sno.value
        spo = self.params.initial.spo.value
        si = self.params.initial.si.value
        salk = self.params.initial.salk.value
        snn = self.params.initial.snn.value
        xi = self.params.initial.xi.value
        xs = self.params.initial.xs.value
        xh = self.params.initial.xh.value
        xpao = self.params.initial.xpao.value
        xpp = self.params.initial.xpp.value
        xpha = self.params.initial.xpha.value
        xaut = self.params.initial.xaut.value
        xmep = self.params.initial.xmep.value
        xmeoh = self.params.initial.xmeoh.value
        xii = self.params.initial.xii.value

        y = [so, sf, sa, snh, sno, spo, si, salk, snn, xi, xs, xh, xpao, xpp, xpha, xaut, xmeoh, xmep, xii]

        self.variables.so.value = so
        self.variables.sf.value = sf
        self.variables.sa.value = sa
        self.variables.snh.value = snh
        self.variables.sno.value = sno
        self.variables.spo.value = spo
        self.variables.si.value = si
        self.variables.salk.value = salk
        self.variables.snn.value = snn
        self.variables.xi.value = xi
        self.variables.xs.value = xs
        self.variables.xh.value = xh
        self.variables.xpao.value = xpao
        self.variables.xpp.value = xpp
        self.variables.xpha.value = xpha
        self.variables.xaut.value = xaut
        self.variables.xmep.value = xmep
        self.variables.xmeoh.value = xmeoh
        self.variables.xii.value = xii

        cod, bod, tss, tn, tp = PublicFun.asm2d_get_compos(y, self.params.stoichi)
        self.variables.cod.value = cod
        self.variables.bod.value = bod
        self.variables.tss.value = tss
        self.variables.tn.value = tn
        self.variables.tp.value = tp

        # 进水
        self.variables.so_in.init_result(times)
        self.variables.sf_in.init_result(times)
        self.variables.sa_in.init_result(times)
        self.variables.snh_in.init_result(times)
        self.variables.sno_in.init_result(times)
        self.variables.spo_in.init_result(times)
        self.variables.si_in.init_result(times)
        self.variables.salk_in.init_result(times)
        self.variables.snn_in.init_result(times)
        self.variables.xi_in.init_result(times)
        self.variables.xs_in.init_result(times)
        self.variables.xh_in.init_result(times)
        self.variables.xpao_in.init_result(times)
        self.variables.xpp_in.init_result(times)
        self.variables.xpha_in.init_result(times)
        self.variables.xaut_in.init_result(times)
        self.variables.xmep_in.init_result(times)
        self.variables.xmeoh_in.init_result(times)
        self.variables.xii_in.init_result(times)

        # 出水
        self.variables.so.init_result(times)
        self.variables.sf.init_result(times)
        self.variables.sa.init_result(times)
        self.variables.snh.init_result(times)
        self.variables.sno.init_result(times)
        self.variables.spo.init_result(times)
        self.variables.si.init_result(times)
        self.variables.salk.init_result(times)
        self.variables.snn.init_result(times)
        self.variables.xi.init_result(times)
        self.variables.xs.init_result(times)
        self.variables.xh.init_result(times)
        self.variables.xpao.init_result(times)
        self.variables.xpp.init_result(times)
        self.variables.xpha.init_result(times)
        self.variables.xaut.init_result(times)
        self.variables.xmep.init_result(times)
        self.variables.xmeoh.init_result(times)
        self.variables.xii.init_result(times)

        # 汇流
        self.variables.so_converge.init_result(times)
        self.variables.sf_converge.init_result(times)
        self.variables.sa_converge.init_result(times)
        self.variables.snh_converge.init_result(times)
        self.variables.sno_converge.init_result(times)
        self.variables.spo_converge.init_result(times)
        self.variables.si_converge.init_result(times)
        self.variables.salk_converge.init_result(times)
        self.variables.snn_converge.init_result(times)
        self.variables.xi_converge.init_result(times)
        self.variables.xs_converge.init_result(times)
        self.variables.xh_converge.init_result(times)
        self.variables.xpao_converge.init_result(times)
        self.variables.xpp_converge.init_result(times)
        self.variables.xpha_converge.init_result(times)
        self.variables.xaut_converge.init_result(times)
        self.variables.xmep_converge.init_result(times)
        self.variables.xmeoh_converge.init_result(times)
        self.variables.xii_converge.init_result(times)

        self.variables.cod.init_result(times)
        self.variables.bod.init_result(times)
        self.variables.tss.init_result(times)
        self.variables.tn.init_result(times)
        self.variables.tp.init_result(times)

    def get_port_by_id(self, pid):
        """通过port id 获取port"""
        return self.ports.set.get(pid)

    def save_result(self):
        result = {}
        for var_name, var_object in self.variables.set.items():
            if var_object.is_save:
                result[var_name] = list(var_object.results)
        return result

    def get_current_result(self):
        return {var_name: round(var_object.value, 3) for var_name, var_object in
                self.variables.set.items()}

    def set_save_var(self, names: list):
        """设置需要保存结果的变量"""
        for name in names:
            var_object = self.variables.set.get(name)
            if var_object:
                var_object.is_save = True

    def set_init_params(self, y):
        var_list = ["so", "sf", "sa", "snh", "sno", "spo", "si", "salk", "snn", "xi", "xs", "xh", "xpao", "xpp", "xpha",
                    "xaut", "xmeoh", "xmep", "xii"]

        initial_data = {
            "initial": {v_name: {'value': y[index]} for index, v_name in enumerate(var_list)}
        }
        self.set_params(initial_data)

    def update_param_by_t(self, t: float):
        """根据时间t更新为时间序列的参数的参数值"""
        self.params.update_by_t(t)

    def ode_fun(self, qin, yin, y, process):
        """
        AMS2D模型方程定义
        :param qin: 进入CSTR的进水流量
        :param yin: 进入CSTR的进水组分浓度
        :param y: CSTR内的待求变量，即ASM2d模型的组分
        :param process: 流程对象
        :return:
        """
        y[y < 0.0] = 0.0  # 求解过程中将小于零的结果强制归零，否则会引起结果异常
        volume = self.params.physical.volume.value  # 体积
        q_pump = self.variables.flow_pump.value  # 抽水流量
        q_air = self.params.operation.q_air.value  # 曝气量
        temp_ref = self.params.environment.temp_ref.value
        temp = self.params.environment.temp.value

        # 计算混合项
        q_out = qin - q_pump
        dyq = (qin * yin - q_out * y - q_pump * y) / volume

        # 计算反应项
        so, sf, sa, snh, sno, spo, si, salk, snn, xi, xs, xh, xpao, xpp, xpha, xaut, xmeoh, xmep, xii = y

        # 动力学参数 Kinetic Parameter
        # 水解
        kh_hydro_temp_ref = self.params.kinetic.kh_hydro_temp_ref.value
        gno_hydro = self.params.kinetic.gno_hydro.value
        gfe_hydro = self.params.kinetic.gfe_hydro.value
        ko_hydro = self.params.kinetic.ko_hydro.value
        kno_hydro = self.params.kinetic.kno_hydro.value
        kx_hydro = self.params.kinetic.kx_hydro.value
        # 异养菌
        uh_herter_temp_ref = self.params.kinetic.uh_herter_temp_ref.value
        qfe_herter_temp_ref = self.params.kinetic.qfe_herter_temp_ref.value
        bh_herter_temp_ref = self.params.kinetic.bh_herter_temp_ref.value
        gno_herter = self.params.kinetic.gno_herter.value
        ko_herter = self.params.kinetic.ko_herter.value
        kf_herter = self.params.kinetic.kf_herter.value
        kfe_herter = self.params.kinetic.kfe_herter.value
        ka_herter = self.params.kinetic.ka_herter.value
        kno_herter = self.params.kinetic.kno_herter.value
        knh_herter = self.params.kinetic.knh_herter.value
        kp_herter = self.params.kinetic.kp_herter.value
        kalk_herter = self.params.kinetic.kalk_herter.value
        # 聚磷菌
        qpha_phos_temp_ref = self.params.kinetic.qpha_phos_temp_ref.value
        qpp_phos_temp_ref = self.params.kinetic.qpp_phos_temp_ref.value
        upao_phos_temp_ref = self.params.kinetic.upao_phos_temp_ref.value
        bpao_phos_temp_ref = self.params.kinetic.bpao_phos_temp_ref.value
        bpp_phos_temp_ref = self.params.kinetic.bpp_phos_temp_ref.value
        bpha_phos_temp_ref = self.params.kinetic.bpha_phos_temp_ref.value
        gno_phos = self.params.kinetic.gno_phos.value
        ko_phos = self.params.kinetic.ko_phos.value
        kno_phos = self.params.kinetic.kno_phos.value
        ka_phos = self.params.kinetic.ka_phos.value
        knh_phos = self.params.kinetic.knh_phos.value
        kps_phos = self.params.kinetic.kps_phos.value
        kp_phos = self.params.kinetic.kp_phos.value
        kalk_phos = self.params.kinetic.kalk_phos.value
        kpp_phos = self.params.kinetic.kpp_phos.value
        kmax_phos = self.params.kinetic.kmax_phos.value
        kipp_phos = self.params.kinetic.kipp_phos.value
        kpha_phos = self.params.kinetic.kpha_phos.value
        # 自养菌
        u_aut_temp_ref = self.params.kinetic.uAut_temp_ref.value
        b_aut_temp_ref = self.params.kinetic.bAut_temp_ref.value
        ko_aut = self.params.kinetic.ko_aut.value
        knh_aut = self.params.kinetic.knh_aut.value
        kalk_aut = self.params.kinetic.kalk_aut.value
        kp_aut = self.params.kinetic.kp_aut.value
        # 沉淀和再溶解
        kpre = self.params.kinetic.kpre.value
        kred = self.params.kinetic.kred.value
        kalk_pre = self.params.kinetic.kalk_pre.value

        kh_hydro = kh_hydro_temp_ref * 1.0414 ** (temp - temp_ref)
        uh_herter = uh_herter_temp_ref * 1.07177 ** (temp - temp_ref)
        qfe_herter = qfe_herter_temp_ref * 1.07177 ** (temp - temp_ref)
        bh_herter = bh_herter_temp_ref * 1.07177 ** (temp - temp_ref)
        qpha_phos = qpha_phos_temp_ref * 1.0414 ** (temp - temp_ref)
        qpp_phos = qpp_phos_temp_ref * 1.0414 ** (temp - temp_ref)
        upao_phos = upao_phos_temp_ref * 1.0409 ** (temp - temp_ref)
        bpao_phos = bpao_phos_temp_ref * 1.07177 ** (temp - temp_ref)
        bpp_phos = bpp_phos_temp_ref * 1.07177 ** (temp - temp_ref)
        bpha_phos = bpha_phos_temp_ref * 1.07177 ** (temp - temp_ref)
        u_aut = u_aut_temp_ref * 1.1107 ** (temp - temp_ref)
        b_aut = b_aut_temp_ref * 1.1161 ** (temp - temp_ref)

        # 化学计量学系数
        icv = self.params.stoichi.icv.value
        ivt = self.params.stoichi.ivt.value
        fbod = self.params.stoichi.ivt.value

        insi = self.params.stoichi.insi.value
        insf = self.params.stoichi.insf.value
        inxi = self.params.stoichi.inxi.value
        inxs = self.params.stoichi.inxs.value
        inbm = self.params.stoichi.inbm.value

        ipsi = self.params.stoichi.ipsi.value
        ipsf = self.params.stoichi.ipsf.value
        ipxi = self.params.stoichi.ipxi.value
        ipxs = self.params.stoichi.ipxs.value
        ipbm = self.params.stoichi.ipbm.value

        itssxi = self.params.stoichi.itssxi.value
        itssxs = self.params.stoichi.itssxs.value
        itssbm = self.params.stoichi.itssbm.value

        fsi = self.params.stoichi.fsi.value
        yh = self.params.stoichi.yh.value
        yaut = self.params.stoichi.yaut.value
        fxi = self.params.stoichi.fxi.value
        ypao = self.params.stoichi.ypao.value
        ypo = self.params.stoichi.ypo.value
        ypha = self.params.stoichi.ypha.value

        # so
        coeff_so4 = 1.0 - 1.0 / yh
        coeff_so5 = 1.0 - 1.0 / yh
        coeff_so11 = - ypha
        coeff_so13 = 1.0 - 1.0 / ypao
        coeff_so18 = -(4.57 - yaut) / yaut

        # sf
        coeff_sf1 = 1.0 - fsi
        coeff_sf2 = 1.0 - fsi
        coeff_sf3 = 1.0 - fsi
        coeff_sf4 = - 1.0 / yh
        coeff_sf6 = - 1.0 / yh
        coeff_sf8 = - 1.0

        # sa
        coeff_sa5 = - 1.0 / yh
        coeff_sa7 = - 1.0 / yh
        coeff_sa8 = 1.0
        coeff_sa10 = - 1.0
        coeff_sa17 = 1.0

        # snh
        coeff_snh1 = inxs - (1.0 - fsi) * insf - fsi * insi
        coeff_snh2 = inxs - (1.0 - fsi) * insf - fsi * insi
        coeff_snh3 = inxs - (1.0 - fsi) * insf - fsi * insi
        coeff_snh4 = insf / yh - inbm
        coeff_snh5 = - inbm
        coeff_snh6 = insf / yh - inbm
        coeff_snh7 = - inbm
        coeff_snh8 = insf
        coeff_snh9 = inbm - fxi * inxi - (1.0 - fxi) * inxs
        coeff_snh13 = - inbm
        coeff_snh14 = - inbm
        coeff_snh15 = inbm - fxi * inxi - (1.0 - fxi) * inxs
        coeff_snh18 = -1.0 / yaut - inbm
        coeff_snh19 = inbm - fxi * inxi - (1.0 - fxi) * inxs

        # sno
        coeff_sno6 = - (1.0 - yh) / (2.86 * yh)
        coeff_sno7 = - (1.0 - yh) / (2.86 * yh)
        coeff_sno12 = - ypha / 2.86
        coeff_sno14 = (1.0 - 1.0 / ypao) / 2.86
        coeff_sno18 = 1.0 / yaut

        # spo
        coeff_spo1 = ipxs - ipsi * fsi - (1.0 - fsi) * ipsf
        coeff_spo2 = ipxs - ipsi * fsi - (1.0 - fsi) * ipsf
        coeff_spo3 = ipxs - ipsi * fsi - (1.0 - fsi) * ipsf
        coeff_spo4 = ipsf / yh - ipbm
        coeff_spo5 = - ipbm
        coeff_spo6 = ipsf / yh - ipbm
        coeff_spo7 = - ipbm
        coeff_spo8 = ipsf
        coeff_spo9 = ipbm - ipxi * fxi - (1.0 - fxi) * ipxs
        coeff_spo10 = ypo
        coeff_spo11 = - 1.0
        coeff_spo12 = - 1.0
        coeff_spo13 = - ipbm
        coeff_spo14 = - ipbm
        coeff_spo15 = ipbm - ipxi * fxi - (1.0 - fxi) * ipxs
        coeff_spo16 = 1.0
        coeff_spo18 = - ipbm
        coeff_spo19 = ipbm - ipxi * fxi - (1.0 - fxi) * ipxs
        coeff_spo20 = - 1.0
        coeff_spo21 = 1.0

        # si
        coeff_si1 = fsi
        coeff_si2 = fsi
        coeff_si3 = fsi

        # salk
        coeff_salk1 = coeff_snh1 / 14.0 - 1.5 * coeff_spo1 / 31.0
        coeff_salk2 = coeff_snh2 / 14.0 - 1.5 * coeff_spo2 / 31.0
        coeff_salk3 = coeff_snh3 / 14.0 - 1.5 * coeff_spo3 / 31.0
        coeff_salk4 = coeff_snh4 / 14.0 - 1.5 * coeff_spo4 / 31.0
        coeff_salk5 = 1.0 / (64.0 * yh) + coeff_snh5 / 14.0 - 1.5 * coeff_spo5 / 31.0
        coeff_salk6 = coeff_snh6 / 14.0 - 1.5 * coeff_spo6 / 31.0 + (1.0 - yh) / (14.0 * 2.86 * yh)
        coeff_salk7 = coeff_snh7 / 14.0 - 1.5 * coeff_spo7 / 31.0 + 1.0 / (64.0 * yh) + (1.0 - yh) / (14.0 * 2.86 * yh)
        coeff_salk8 = -1.0 / 64.0 + coeff_snh8 / 14.0 - 1.5 * coeff_spo8 / 31.0
        coeff_salk9 = coeff_snh9 / 14.0 - 1.5 * coeff_spo9 / 31.0
        coeff_salk10 = 1.0 / 64.0 - 0.5 * ypo / 31.0
        coeff_slak11 = 0.5 / 31.0
        coeff_salk12 = ypha / (2.86 * 14.0) + 0.5 / 31.0
        coeff_salk13 = - inbm / 14.0 + 1.5 * ipbm / 31.0
        coeff_salk14 = coeff_snh14 / 14.0 - coeff_sno14 / 14.0 + 1.5 * ipbm / 31.0
        coeff_salk15 = coeff_snh15 / 14.0 - 1.5 * coeff_spo15 / 31.0
        coeff_salk16 = - 0.5 / 31.0
        coeff_salk17 = - 1.0 / 64.0
        coeff_salk18 = coeff_snh18 / 14.0 - 1.0 / (14.0 * yaut) + 1.5 * ipbm / 31.0
        coeff_salk19 = coeff_snh19 / 14.0 - 1.5 * coeff_spo19 / 31.0
        coeff_salk20 = 1.5 / 31.0
        coeff_salk21 = - 1.5 / 31.0

        # snn
        coeff_snn6 = (1.0 - yh) / (2.86 * yh)
        coeff_snn7 = (1.0 - yh) / (2.86 * yh)
        coeff_snn12 = ypha / 2.86
        coeff_snn14 = -(1.0 - 1.0 / ypao) / 2.86

        # xi
        coeff_xi9 = fxi
        coeff_xi15 = fxi
        coeff_xi19 = fxi

        # xs
        coeff_xs1 = -1.0
        coeff_xs2 = -1.0
        coeff_xs3 = -1.0
        coeff_xs9 = 1.0 - fxi
        coeff_xs15 = 1.0 - fxi
        coeff_xs19 = 1.0 - fxi

        # xh
        coeff_xh4 = 1.0
        coeff_xh5 = 1.0
        coeff_xh6 = 1.0
        coeff_xh7 = 1.0
        coeff_xh9 = -1.0

        # xpao
        coeff_xpao13 = 1.0
        coeff_xpao14 = 1.0
        coeff_xpao15 = -1.0

        # xpp
        coeff_xpp10 = - ypo
        coeff_xpp11 = 1.0
        coeff_xpp12 = 1.0
        coeff_xpp16 = -1.0

        # xpha
        coeff_xpha10 = 1.0
        coeff_xpha11 = - ypha
        coeff_xpha12 = - ypha
        coeff_xpha13 = - 1.0 / ypao
        coeff_xpha14 = - 1.0 / ypao
        coeff_xpha17 = - 1.0

        # xaut
        coeff_xaut18 = 1.0
        coeff_xaut19 = - 1.0

        # xmeoh
        coeff_xmeoh20 = -3.45
        coeff_xmeoh21 = 3.45

        # xmep
        coeff_xmep20 = 4.87
        coeff_xmep21 = -4.87

        # 饱和与抑制函数

        # 颗粒基质的水解:xs
        so_satu_hydro = so / (ko_hydro + so)
        sub_satu_hydro = (xs / xh) / (kx_hydro + xs / xh)
        sno3_satu_hydro = sno / (kno_hydro + sno)
        so_inh_hydro = ko_hydro / (ko_hydro + so)
        sno_inh_hydro = kno_hydro / (kno_hydro + sno)

        # 异养菌的有机生长过程:xh
        so_satu_herter = so / (ko_herter + so)
        sf_satu1_herter = sf / (kf_herter + sf)
        sf_satu2_herter = sf / (sf + sa)
        sf_satu3_herter = sf / (kfe_herter + sf)
        snh_satu_herter = snh / (knh_herter + snh)
        spo_satu_herter = spo / (kp_herter + spo)
        salk_satu_herter = salk / (kalk_herter + salk)
        sa_satu1_herter = sa / (ka_herter + sa)
        sa_satu2_herter = sa / (sf + sa)
        sno3_satu_herter = sno / (kno_herter + sno)
        so_inh_herter = ko_herter / (ko_herter + so)
        sno3_inh_herter = kno_herter / (kno_herter + sno)

        # 聚磷菌的有机生长过程:xpao
        sa_satu_phos = sa / (ka_phos + sa)
        salk_satu_phos = salk / (kalk_phos + salk)
        xpp_satu_phos = (xpp / xpao) / (kpp_phos + (xpp / xpao))
        so_satu_phos = so / (ko_phos + so)
        xpah_satu_phos = (xpha / xpao) / (kpha_phos + (xpha / xpao))
        sno3_satu_phos = sno / (kno_phos + sno)
        spo_satu1_phos = spo / (kps_phos + spo)
        spo_satu2_phos = spo / (kp_phos + spo)
        snh_satu_phos = snh / (knh_phos + snh)
        sub_inh_phos = (kmax_phos - (xpp / xpao)) / (kipp_phos + kmax_phos - (xpp / xpao))
        so_inh_phos = ko_phos / (ko_phos + so)

        # 硝化菌（自养菌）的有机生长过程:xaut
        so_satu_aut = so / (ko_aut + so)
        snh_satu_aut = snh / (knh_aut + snh)
        spo_satu_aut = spo / (kp_aut + spo)
        salk_satu_aut = salk / (kalk_aut + salk)

        # 化学沉淀
        salk_satu_pre = salk / (kalk_pre + salk)

        # 颗粒基质的水解:xs
        r1 = kh_hydro * so_satu_hydro * sub_satu_hydro * xh
        r2 = kh_hydro * gno_hydro * so_inh_hydro * sno3_satu_hydro * sub_satu_hydro * xh
        r3 = kh_hydro * gfe_hydro * so_inh_hydro * sno_inh_hydro * sub_satu_hydro * xh

        # 异养菌的有机生长过程:xh
        r4 = uh_herter * so_satu_herter * sf_satu1_herter * sf_satu2_herter * snh_satu_herter * spo_satu_herter * salk_satu_herter * xh
        r5 = uh_herter * so_satu_herter * sa_satu1_herter * sa_satu2_herter * snh_satu_herter * spo_satu_herter * salk_satu_herter * xh
        r6 = uh_herter * gno_herter * so_inh_herter * sf_satu1_herter * sf_satu2_herter * snh_satu_herter * sno3_satu_herter * spo_satu_herter * salk_satu_herter * xh
        r7 = uh_herter * gno_herter * so_inh_herter * sa_satu1_herter * sa_satu2_herter * snh_satu_herter * sno3_satu_herter * spo_satu_herter * salk_satu_herter * xh
        r8 = qfe_herter * so_inh_herter * sno3_inh_herter * sf_satu3_herter * salk_satu_herter * xh
        r9 = bh_herter * xh

        # 聚磷菌的有机生长过程:xpao
        r10 = qpha_phos * sa_satu_phos * salk_satu_phos * xpp_satu_phos * xpao
        r11 = qpp_phos * so_satu_phos * spo_satu1_phos * salk_satu_phos * xpah_satu_phos * sub_inh_phos * xpao
        r12 = qpp_phos * gno_phos * so_inh_phos * sno3_satu_phos * spo_satu1_phos * salk_satu_phos * xpah_satu_phos * sub_inh_phos * xpao
        r13 = upao_phos * so_satu_phos * snh_satu_phos * salk_satu_phos * spo_satu2_phos * xpah_satu_phos * xpao
        r14 = upao_phos * gno_phos * so_inh_phos * sno3_satu_phos * snh_satu_phos * salk_satu_phos * spo_satu2_phos * xpah_satu_phos * xpao
        r15 = bpao_phos * salk_satu_phos * xpao
        r16 = bpp_phos * salk_satu_phos * xpp
        r17 = bpha_phos * salk_satu_phos * xpha

        # 硝化菌（自养菌）的有机生长过程:xaut
        r18 = u_aut * so_satu_aut * snh_satu_aut * spo_satu_aut * salk_satu_aut * xaut
        r19 = b_aut * xaut

        # 化学沉淀
        r20 = kpre * spo * xmeoh
        r21 = kred * salk_satu_pre * xmep

        #  ********************曝气*****************
        ea = self.params.aerator.ea.value
        alpha_fine = self.params.aerator.alpha_fine.value
        beta = self.params.aerator.beta.value
        so_satu20 = self.params.aerator.sosatu20.value
        sote = self.params.aerator.sote.value
        aerator_depth = self.params.aerator.aerator_depth.value

        cf1 = ea * 10.0
        ya = q_air / volume
        delta = 1.0 + 0.03858 * aerator_depth
        so_sat = so_satu20 * beta * delta
        so_sat_field = 468.0 / (31.6 + temp) * beta * delta
        temp_adjust = 1.024 ** (temp - temp_ref)

        do_fun = cf1 * ya * alpha_fine * sote * (so_sat - so) / so_sat

        dsor = coeff_so4 * r4 + coeff_so5 * r5 + coeff_so11 * r11 + coeff_so13 * r13 + coeff_so18 * r18 + do_fun
        dsfr = coeff_sf1 * r1 + coeff_sf2 * r2 + coeff_sf3 * r3 + coeff_sf4 * r4 + coeff_sf6 * r6 + coeff_sf8 * r8
        dsar = coeff_sa5 * r5 + coeff_sa7 * r7 + coeff_sa8 * r8 + coeff_sa10 * r10 + coeff_sa17 * r17
        dsnhr = coeff_snh1 * r1 + coeff_snh2 * r2 + coeff_snh3 * r3 + coeff_snh4 * r4 + coeff_snh5 * r5 + coeff_snh6 * r6 + coeff_snh7 * r7 + coeff_snh8 * r8 + coeff_snh9 * r9 + coeff_snh13 * r13 + coeff_snh14 * r14 + coeff_snh15 * r15 + coeff_snh18 * r18 + coeff_snh19 * r19
        dsnor = coeff_sno6 * r6 + coeff_sno7 * r7 + coeff_sno12 * r12 + coeff_sno14 * r14 + coeff_sno18 * r18
        dspor = coeff_spo1 * r1 + coeff_spo2 * r2 + coeff_spo3 * r3 + coeff_spo4 * r4 + coeff_spo5 * r5 + coeff_spo6 * r6 + coeff_spo7 * r7 + coeff_spo8 * r8 + coeff_spo9 * r9 + coeff_spo10 * r10 + coeff_spo11 * r11 + coeff_spo12 * r12 + coeff_spo13 * r13 + coeff_spo14 * r14 + coeff_spo15 * r15 + coeff_spo16 * r16 + coeff_spo18 * r18 + coeff_spo19 * r19 + coeff_spo20 * r20 + coeff_spo21 * r21
        dsir = coeff_si1 * r1 + coeff_si2 * r2 + coeff_si3 * r3
        dsalkr = coeff_salk1 * r1 + coeff_salk2 * r2 + coeff_salk3 * r3 + coeff_salk4 * r4 + coeff_salk5 * r5 + coeff_salk6 * r6 + coeff_salk7 * r7 + coeff_salk8 * r8 + coeff_salk9 * r9 + coeff_salk10 * r10 + coeff_slak11 * r11 + coeff_salk12 * r12 + coeff_salk13 * r13 + coeff_salk14 * r14 + coeff_salk15 * r15 + coeff_salk16 * r16 + coeff_salk17 * r17 + coeff_salk18 * r18 + coeff_salk19 * r19 + coeff_salk20 * r20 + coeff_salk21 * r21
        dsnnr = coeff_snn6 * r6 + coeff_snn7 * r7 + coeff_snn12 * r12 + coeff_snn14 * r14
        dxir = coeff_xi9 * r9 + coeff_xi15 * r15 + coeff_xi19 * r19
        dxsr = coeff_xs1 * r1 + coeff_xs2 * r2 + coeff_xs3 * r3 + coeff_xs9 * r9 + coeff_xs15 * r15 + coeff_xs19 * r19
        dxhr = coeff_xh4 * r4 + coeff_xh5 * r5 + coeff_xh6 * r6 + coeff_xh7 * r7 + coeff_xh9 * r9
        dxpaor = coeff_xpao13 * r13 + coeff_xpao14 * r14 + coeff_xpao15 * r15
        dxppr = coeff_xpp10 * r10 + coeff_xpp11 * r11 + coeff_xpp12 * r12 + coeff_xpp16 * r16
        dxphar = coeff_xpha10 * r10 + coeff_xpha11 * r11 + coeff_xpha12 * r12 + coeff_xpha13 * r13 + coeff_xpha14 * r14 + coeff_xpha17 * r17
        dxautr = coeff_xaut18 * r18 + coeff_xaut19 * r19
        dxmeohr = coeff_xmeoh20 * r20 + coeff_xmeoh21 * r21
        dxmepr = coeff_xmep20 * r20 + coeff_xmep21 * r21
        dxiir = 0.0

        # ASM2d模型组分的微分项
        dyr = [dsor, dsfr, dsar, dsnhr, dsnor, dspor, dsir, dsalkr, dsnnr, dxir, dxsr, dxhr, dxpaor, dxppr, dxphar,
               dxautr, dxmeohr, dxmepr, dxiir]

        # ************净变化率************
        dy = dyq + dyr

        return dy
