# -*- coding: utf-8 -*-
from modellibrary.src.main.python.core.common.variable import Variable
from ..constants import TakacsDefaultValue, TakacsTypeName


class TakacsParams:
    def __init__(self):
        self.v_bdn = Variable(name=TakacsTypeName.V_BDN, default=TakacsDefaultValue.V_BDN)
        self.v_max = Variable(name=TakacsTypeName.V_MAX, default=TakacsDefaultValue.V_MAX)
        self.rh = Variable(name=TakacsTypeName.RH, default=TakacsDefaultValue.RH)
        self.rp = Variable(name=TakacsTypeName.RP, default=TakacsDefaultValue.RP)
        self.fns = Variable(name=TakacsTypeName.FNS, default=TakacsDefaultValue.FNS)
        self.x_min_max = Variable(name=TakacsTypeName.X_MIN_MAX, default=TakacsDefaultValue.X_MIN_MAX)
        self.xt = Variable(name=TakacsTypeName.XT, default=TakacsDefaultValue.XT)

    def update_by_t(self, t: float):
        self.v_bdn.update_value_by_t(t)
        self.v_max.update_value_by_t(t)
        self.rh.update_value_by_t(t)
        self.rp.update_value_by_t(t)
        self.fns.update_value_by_t(t)
        self.x_min_max.update_value_by_t(t)
        self.xt.update_value_by_t(t)